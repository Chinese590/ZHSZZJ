$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root

$toolsDir = Join-Path $root '.build_tools'
$uvDir = Join-Path $toolsDir 'uv'
$uvExe = Join-Path $uvDir 'uv.exe'
$uvArchive = Join-Path $toolsDir 'uv-x86_64-pc-windows-msvc.zip'
$uvVersion = '0.11.14'
$uvUrls = @(
    ('https://releases.astral.sh/github/uv/releases/download/' + $uvVersion + '/uv-x86_64-pc-windows-msvc.zip'),
    ('https://github.com/astral-sh/uv/releases/download/' + $uvVersion + '/uv-x86_64-pc-windows-msvc.zip')
)
$pythonInstallDir = Join-Path $root '.build_python'
$pythonCacheDir = Join-Path $root '.build_python_cache'
$uvCacheDir = Join-Path $root '.uv_cache'
$venvDir = Join-Path $root '.build_env'
$pythonExe = Join-Path $venvDir 'Scripts\python.exe'
$releaseRoot = Join-Path $root 'release'
$releaseName = 'DataGuard_v1.8.1_Win10_Portable'
$releaseDir = Join-Path $releaseRoot $releaseName
$zipPath = Join-Path $releaseRoot ($releaseName + '.zip')

function Stop-Build([string]$Message) {
    throw $Message
}

function Download-File([string[]]$Urls, [string]$Destination) {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $lastError = 'No download URL was attempted.'
    foreach ($url in $Urls) {
        try {
            Write-Host ('Trying: ' + $url)
            Invoke-WebRequest -Uri $url -OutFile $Destination -UseBasicParsing
            return
        }
        catch {
            $lastError = $_.Exception.Message
            if (Test-Path $Destination) {
                Remove-Item $Destination -Force -ErrorAction SilentlyContinue
            }
        }
    }
    Stop-Build ('Download failed from all configured sources: ' + $lastError)
}

New-Item -ItemType Directory -Force -Path $toolsDir | Out-Null

Write-Host '[1/7] Preparing the portable build manager...'
if (-not (Test-Path $uvExe)) {
    if (-not (Test-Path $uvArchive)) {
        Write-Host ('Downloading uv ' + $uvVersion + '...')
        Download-File $uvUrls $uvArchive
    }

    $extractDir = Join-Path $toolsDir 'uv_extract'
    if (Test-Path $extractDir) {
        Remove-Item $extractDir -Recurse -Force
    }
    New-Item -ItemType Directory -Force -Path $extractDir | Out-Null
    Expand-Archive -Path $uvArchive -DestinationPath $extractDir -Force

    $foundUv = Get-ChildItem -Path $extractDir -Filter 'uv.exe' -File -Recurse | Select-Object -First 1
    if ($null -eq $foundUv) {
        Stop-Build 'uv.exe was not found after extracting the downloaded archive.'
    }

    if (Test-Path $uvDir) {
        Remove-Item $uvDir -Recurse -Force
    }
    New-Item -ItemType Directory -Force -Path $uvDir | Out-Null
    Copy-Item -Path $foundUv.FullName -Destination $uvExe -Force
    Remove-Item $extractDir -Recurse -Force
}

& $uvExe --version
if ($LASTEXITCODE -ne 0) {
    Stop-Build 'The portable build manager could not be started.'
}

$env:UV_PYTHON_INSTALL_DIR = $pythonInstallDir
$env:UV_PYTHON_CACHE_DIR = $pythonCacheDir
$env:UV_CACHE_DIR = $uvCacheDir
$env:UV_PYTHON_NO_REGISTRY = '1'
$env:UV_PYTHON_INSTALL_REGISTRY = '0'
$env:UV_PYTHON_INSTALL_BIN = '0'
$env:UV_NO_MODIFY_PATH = '1'
$env:UV_MANAGED_PYTHON = '1'

# uv python install
Write-Host '[2/7] Preparing a registry-free managed Python 3.11 runtime...'
& $uvExe python install 3.11
if ($LASTEXITCODE -ne 0) {
    Stop-Build 'Managed Python download or installation failed.'
}

# uv venv
if (-not (Test-Path $pythonExe)) {
    if (Test-Path $venvDir) {
        Remove-Item $venvDir -Recurse -Force
    }
    & $uvExe venv --python 3.11 $venvDir
    if ($LASTEXITCODE -ne 0) {
        Stop-Build 'The private build environment could not be created.'
    }
}

if (-not (Test-Path $pythonExe)) {
    Stop-Build 'The private build environment was created but python.exe was not found.'
}

& $pythonExe -c "import sys; import tkinter; assert sys.version_info[:2] == (3, 11); print(sys.executable)"
if ($LASTEXITCODE -ne 0) {
    if (Test-Path $venvDir) {
        Remove-Item $venvDir -Recurse -Force -ErrorAction SilentlyContinue
    }
    Stop-Build 'Build Python validation failed. Python 3.11 or tkinter is unavailable.'
}

Write-Host '[3/7] Installing build dependencies...'
& $uvExe pip install --python $pythonExe -r (Join-Path $root 'requirements-build.txt')
if ($LASTEXITCODE -ne 0) {
    Stop-Build 'Dependency installation failed.'
}

# python -m pytest
Write-Host '[4/7] Running automated tests...'
& $pythonExe -m pytest -q
if ($LASTEXITCODE -ne 0) {
    Stop-Build 'Automated tests failed. Build stopped.'
}

Write-Host '[5/7] Building the Windows portable application...'
foreach ($path in @((Join-Path $root 'build'), (Join-Path $root 'dist'))) {
    if (Test-Path $path) {
        Remove-Item $path -Recurse -Force
    }
}

# python -m PyInstaller
& $pythonExe -m PyInstaller --noconfirm --clean (Join-Path $root 'DataGuard.spec')
if ($LASTEXITCODE -ne 0) {
    Stop-Build 'PyInstaller build failed.'
}

$builtExe = Join-Path $root 'dist\DataGuard\DataGuard.exe'
if (-not (Test-Path $builtExe)) {
    Stop-Build 'Build output is incomplete: DataGuard.exe was not found.'
}

Write-Host '[6/7] Preparing the release folder...'
New-Item -ItemType Directory -Force -Path $releaseRoot | Out-Null
if (Test-Path $releaseDir) {
    Remove-Item $releaseDir -Recurse -Force
}
New-Item -ItemType Directory -Force -Path $releaseDir | Out-Null
Copy-Item -Path (Join-Path $root 'dist\DataGuard\*') -Destination $releaseDir -Recurse -Force
Copy-Item -Path (Join-Path $root 'release_docs\User_Guide.txt') -Destination (Join-Path $releaseDir 'User_Guide.txt') -Force
Copy-Item -Path (Join-Path $root 'release_docs\Release_Notes.txt') -Destination (Join-Path $releaseDir 'Release_Notes.txt') -Force
Copy-Item -Path (Join-Path $root 'release_docs\Start_DataGuard.bat') -Destination (Join-Path $releaseDir 'Start_DataGuard.bat') -Force
Copy-Item -Path (Join-Path $root 'alchemy_config.json') -Destination (Join-Path $releaseDir 'alchemy_config.json') -Force

Write-Host '[7/7] Creating the distribution ZIP...'
if (Test-Path $zipPath) {
    Remove-Item $zipPath -Force
}
Compress-Archive -Path $releaseDir -DestinationPath $zipPath -CompressionLevel Optimal
if (-not (Test-Path $zipPath)) {
    Stop-Build 'ZIP creation failed.'
}

Write-Host ''
Write-Host 'BUILD COMPLETED' -ForegroundColor Green
Write-Host ('Portable folder: ' + $releaseDir)
Write-Host ('Distribution ZIP: ' + $zipPath)
