"""Helpers for launching the companion DataTang QC tool from DataGuard."""

from __future__ import annotations

import os
import subprocess
from pathlib import Path

from alchemy.runtime import application_dir

QC_STATUS_FOLDERS = ("质检完成", "待返修", "待质检", "返修提交")
QC_LAUNCHER_NAME = "DataTangQCTool-Launcher.exe"


def ensure_qc_root(path: str | os.PathLike[str]) -> Path:
    """Create and return a QC workspace with the four required status folders."""
    root = Path(path).expanduser().resolve()
    root.mkdir(parents=True, exist_ok=True)
    for folder in QC_STATUS_FOLDERS:
        (root / folder).mkdir(parents=True, exist_ok=True)
    return root


def find_qc_launcher(extra_candidates: list[str | os.PathLike[str]] | None = None) -> Path | None:
    """Locate the companion launcher next to either frozen DataGuard executable."""
    candidates: list[Path] = []
    env_path = os.environ.get("DATATANG_QC_LAUNCHER", "").strip()
    if env_path:
        candidates.append(Path(env_path))
    if extra_candidates:
        candidates.extend(Path(item) for item in extra_candidates)

    base = Path(application_dir())
    candidates.extend(
        [
            base / QC_LAUNCHER_NAME,
            base / "QC" / QC_LAUNCHER_NAME,
            base.parent / QC_LAUNCHER_NAME,
            base.parent / "QC" / QC_LAUNCHER_NAME,
        ]
    )

    seen: set[str] = set()
    for candidate in candidates:
        normalized = os.path.normcase(os.path.abspath(str(candidate)))
        if normalized in seen:
            continue
        seen.add(normalized)
        if candidate.is_file():
            return candidate.resolve()
    return None


def launch_qc(
    qc_root: str | os.PathLike[str],
    launcher_path: str | os.PathLike[str] | None = None,
) -> subprocess.Popen:
    """Launch the QC companion and pass the selected workspace through the environment."""
    root = ensure_qc_root(qc_root)
    launcher = Path(launcher_path).resolve() if launcher_path else find_qc_launcher()
    if launcher is None or not launcher.is_file():
        raise FileNotFoundError(
            f"未找到 {QC_LAUNCHER_NAME}。请使用 GitHub 发布页中的完整管理员套件。"
        )
    env = os.environ.copy()
    env["DATATANG_QC_ROOT"] = str(root)
    return subprocess.Popen([str(launcher)], cwd=str(launcher.parent), env=env)
