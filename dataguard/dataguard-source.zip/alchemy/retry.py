# alchemy/retry.py
# 文件操作重试器 — 解决文件被占用和 CSV 损坏问题

import os
import shutil
import csv
import time
import errno

from alchemy.constants import MAX_RETRIES, RETRY_DELAY, MSG_LOG


def _is_retryable(error):
    """判断异常是否可重试"""
    if isinstance(error, PermissionError):
        return True
    if isinstance(error, OSError):
        # EBUSY(16), EACCES(13) 可重试
        if error.errno in (errno.EBUSY, errno.EACCES):
            return True
        # Windows 上 PermissionError 可能被包装为 OSError
        if "另一个程序正在使用此文件" in str(error):
            return True
    return False


def _send_log(msg_queue, msg):
    """通过 queue 发送日志（如果 queue 存在）"""
    if msg_queue:
        msg_queue.put((MSG_LOG, msg))


def safe_move(src, dst, max_retries=MAX_RETRIES, retry_delay=RETRY_DELAY, msg_queue=None):
    """
    带重试的文件/目录移动。
    成功返回 (True, "成功")，全部失败返回 (False, "失败原因")
    """
    for attempt in range(max_retries):
        try:
            # 确保目标父目录存在
            parent_dir = os.path.dirname(dst)
            if not os.path.exists(parent_dir):
                os.makedirs(parent_dir)
            if os.path.exists(dst):
                return False, "目标已存在，为防止覆盖已停止操作"
            shutil.move(src, dst)
            return True, "成功" if attempt == 0 else f"重试第{attempt}次后成功"
        except FileNotFoundError:
            return False, "源文件不存在"
        except OSError as e:
            if e.errno == errno.ENOSPC:
                return False, "磁盘空间不足"
            if e.errno == errno.ENAMETOOLONG:
                return False, "路径过长"
            if _is_retryable(e) and attempt < max_retries - 1:
                wait_time = retry_delay * (attempt + 1)
                _send_log(msg_queue, f"⚠️ 文件被占用，{wait_time:.0f}秒后重试 ({attempt + 1}/{max_retries}): {os.path.basename(src)}")
                time.sleep(wait_time)
                continue
            return False, str(e)
        except Exception as e:
            return False, str(e)
    return False, "超过最大重试次数"


def safe_copytree(src, dst, max_retries=MAX_RETRIES, retry_delay=RETRY_DELAY, msg_queue=None):
    """
    带重试的目录复制。
    成功返回 (True, "成功")，全部失败返回 (False, "失败原因")
    """
    for attempt in range(max_retries):
        try:
            if os.path.exists(dst):
                return False, "目标已存在，为防止覆盖已停止操作"
            shutil.copytree(src, dst)
            return True, "成功" if attempt == 0 else f"重试第{attempt}次后成功"
        except FileNotFoundError:
            return False, "源目录不存在"
        except OSError as e:
            if e.errno == errno.ENOSPC:
                return False, "磁盘空间不足"
            if _is_retryable(e) and attempt < max_retries - 1:
                wait_time = retry_delay * (attempt + 1)
                _send_log(msg_queue, f"⚠️ 目录被占用，{wait_time:.0f}秒后重试 ({attempt + 1}/{max_retries}): {os.path.basename(src)}")
                time.sleep(wait_time)
                continue
            return False, str(e)
        except Exception as e:
            return False, str(e)
    return False, "超过最大重试次数"


def atomic_write_csv(filepath, row, headers=None, encoding='utf-8-sig'):
    """
    原子写入 CSV（追加模式）。
    先写临时文件再 os.replace，避免 Excel 锁定导致写入失败。
    """
    tmp_path = filepath + '.tmp'

    file_exists = os.path.exists(filepath) and os.path.getsize(filepath) > 0

    if not file_exists:
        # 新文件：直接写入
        with open(filepath, 'w', newline='', encoding=encoding) as f:
            writer = csv.writer(f)
            if headers:
                writer.writerow(headers)
            writer.writerow(row)
    else:
        # 追加：读取现有内容 → 追加新行 → 原子替换
        read_encoding = encoding
        try:
            with open(filepath, 'r', encoding=encoding) as f:
                content = f.read()
        except (UnicodeDecodeError, UnicodeError):
            try:
                with open(filepath, 'r', encoding='utf-8') as f:
                    content = f.read()
                read_encoding = 'utf-8'
            except (UnicodeDecodeError, UnicodeError):
                with open(filepath, 'r', encoding='gbk') as f:
                    content = f.read()
                read_encoding = 'gbk'

        with open(tmp_path, 'w', newline='', encoding=encoding) as f:
            f.write(content)
            writer = csv.writer(f)
            writer.writerow(row)

        os.replace(tmp_path, filepath)
