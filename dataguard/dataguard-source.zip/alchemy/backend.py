# alchemy/backend.py
# AlchemyBackend - 业务逻辑层

import os
import shutil
import datetime
import re
import csv
import time
import json

from alchemy.constants import (
    build_dirs, VERSION_MSG, DEFAULT_CATEGORIES, DATE_FMT, TIME_FMT,
    DATE_MMDD, RE_BATCH_ID, RE_BATCH_ABANDONED, RE_DATE_DIR, RE_TEAM_TAG,
    RE_GROUP_NAME, RE_GROUP_INNER, IMAGE_EXTENSIONS,
    GROUP_TYPE_FOLDER, GROUP_TYPE_IMAGE, GROUP_TYPE_EMPTY, GROUP_TYPE_MIXED,
    CSV_HEADERS, CSV_LOG_PREFIX, CSV_ENCODINGS, USER_DONE, USER_REWORK,
    USER_TODO, USER_TOOLBOX, QC_NEW, QC_REWORK, QC_ABANDONED,
    ACTION_DIST, ACTION_HARVEST_NEW, ACTION_HARVEST_REWORK,
    ACTION_HARVEST_RECYCLE, ACTION_QA_DIST,
    STATUS_NORMAL, STATUS_REWORK_NEW, STATUS_REWORK_REWORK,
    STATUS_ABANDONED_NEW, STATUS_ABANDONED_REWORK, STATUS_RECYCLE,
    RESULT_SUCCESS, RESULT_FAIL,
    QA_TYPE_NEW, QA_TYPE_REWORK, QA_DESC_NEW, QA_DESC_REWORK,
    RECOVERY_CATEGORIES_FILE, CATEGORY_MARKER_FILE,
)
from alchemy.retry import safe_move as retry_move, safe_copytree as retry_copytree, atomic_write_csv
from alchemy.logger import setup_logger
from alchemy.excel_logger import ExcelOperationLogger


class AlchemyBackend:
    def __init__(self):
        self.project_root = ""
        self.log_callback = None
        self.logger = None
        self.dirs = {}
        self._stats_cache = None
        self._stats_cache_ts = 0
        self.excel_logger = None

    def set_root(self, path):
        self.project_root = path
        self.dirs = build_dirs(path)

        if not os.path.exists(self.dirs["LOGS"]):
            try:
                os.makedirs(self.dirs["LOGS"])
            except OSError:
                pass

        if not os.path.exists(self.dirs["NEWBIE_TOOLS"]):
            try:
                os.makedirs(self.dirs["NEWBIE_TOOLS"])
            except OSError:
                pass

        self._stats_cache = None
        try:
            self.logger = setup_logger(self.dirs["LOGS"])
        except OSError:
            self.logger = None
        self.excel_logger = ExcelOperationLogger(self.dirs["LOGS"])
        return True, VERSION_MSG

    def init_directories(self):
        if not self.project_root:
            return False, "请先设置根路径"

        dirs_to_create = [
            self.dirs["RAW"],
            self.dirs["DIST"],
            self.dirs["QC"],
            self.dirs["LOGS"],
            self.dirs["SYSTEM"],
            self.dirs["NEWBIE_TOOLS"],
            self.dirs["PSD_BACKUP"],
        ]

        created = []
        failed = []
        for path in dirs_to_create:
            if not os.path.exists(path):
                try:
                    os.makedirs(path)
                    created.append(os.path.basename(path))
                except OSError as e:
                    failed.append(f"{os.path.basename(path)}: {e}")

        if failed:
            return False, f"创建失败: {', '.join(failed)}"

        for cat in DEFAULT_CATEGORIES:
            cat_path = os.path.join(self.dirs["RAW"], cat)
            if not os.path.exists(cat_path):
                try:
                    os.makedirs(cat_path)
                except OSError:
                    pass

        return True, "✅ 目录结构已创建完成"

    @staticmethod
    def validate_user_name(username):
        """Validate one Windows-safe directory name for a worker."""
        if not isinstance(username, str) or not username:
            return False, "用户名不能为空"
        if username != username.strip():
            return False, "用户名首尾不能包含空格"
        if username in (".", "..") or username.endswith((".", " ")):
            return False, "用户名不能以句点或空格结尾"
        if any(ord(ch) < 32 for ch in username) or re.search(r'[<>:"/\\|?*]', username):
            return False, "用户名包含 Windows 不允许的字符"
        reserved = {"CON", "PRN", "AUX", "NUL"}
        reserved.update({f"COM{i}" for i in range(1, 10)})
        reserved.update({f"LPT{i}" for i in range(1, 10)})
        if username.split(".", 1)[0].upper() in reserved:
            return False, "用户名不能使用 Windows 保留名称"
        if len(username) > 100:
            return False, "用户名不能超过100个字符"
        return True, ""

    def create_user_folders(self, username):
        if not self.project_root:
            return False, "请先设置根路径"
        valid, reason = self.validate_user_name(username)
        if not valid:
            return False, reason

        user_dist_path = os.path.join(self.dirs["DIST"], username)
        if os.path.exists(user_dist_path):
            return False, f"用户 [{username}] 已存在"

        try:
            os.makedirs(os.path.join(user_dist_path, USER_DONE))
            os.makedirs(os.path.join(user_dist_path, USER_REWORK))
            os.makedirs(os.path.join(user_dist_path, USER_TODO))

            toolbox_path = os.path.join(user_dist_path, USER_TOOLBOX)
            os.makedirs(toolbox_path)

            if os.path.exists(self.dirs["NEWBIE_TOOLS"]):
                for item in os.listdir(self.dirs["NEWBIE_TOOLS"]):
                    src = os.path.join(self.dirs["NEWBIE_TOOLS"], item)
                    dst = os.path.join(toolbox_path, item)
                    if os.path.isdir(src):
                        shutil.copytree(src, dst)
                    else:
                        shutil.copy2(src, dst)

            self._sync_user_categories(username)
            return True, f"✅ 用户 [{username}] 创建完成"
        except OSError as e:
            return False, f"创建失败: {e}"

    def log(self, message):
        if self.log_callback:
            self.log_callback(message)
        if self.logger:
            self.logger.info(message)

    def close(self):
        """释放日志文件句柄，供退出和测试清理使用。"""
        if self.logger:
            for handler in list(self.logger.handlers):
                handler.close()
                self.logger.removeHandler(handler)
            self.logger = None

    # TODO Phase 2: open_folder 和 open_file_directly 应迁移到 UI 层

    def get_user_path(self, username: str) -> str:
        """获取用户目录路径"""
        return os.path.join(self.dirs["DIST"], username)

    def get_qc_subpath(self, *parts) -> str:
        """获取 QC 目录下的子路径"""
        return os.path.join(self.dirs["QC"], *parts)

    def write_csv_log(self, action, user, folder_name, status, result, remark="-",
                      recovery_path=(), image_count=0, task_count=1,
                      content_type="任务文件夹"):
        """保留旧方法名以兼容调用；v1.8 写入每日 Excel 工作簿。"""
        if not self.excel_logger:
            return
        category1, category2 = self._category_parts(recovery_path)
        work_type = "返修" if action == ACTION_HARVEST_REWORK else "新标"
        payload = {
            "action": action, "user": user, "task_id": folder_name,
            "result": result, "category1": category1, "category2": category2,
            "content_type": content_type, "image_count": image_count,
            "task_count": task_count, "work_type": work_type,
            "remark": remark, "status": status,
        }
        try:
            self._replay_pending_logs()
            self.excel_logger.append(**payload)
            return True
        except Exception as e:
            self.log(f"❌ 写入日志失败: {e}")
            try:
                with open(self._pending_logs_path(), "a", encoding="utf-8") as f:
                    f.write(json.dumps(payload, ensure_ascii=False) + "\n")
            except OSError as fallback_error:
                self.log(f"❌ 待补写日志也保存失败: {fallback_error}")
            return False

    def _pending_logs_path(self):
        return os.path.join(self.dirs["LOGS"], "日志待补写.jsonl")

    def _replay_pending_logs(self):
        path = self._pending_logs_path()
        if not os.path.exists(path):
            return
        with open(path, "r", encoding="utf-8") as f:
            rows = [json.loads(line) for line in f if line.strip()]
        remaining = []
        for index, payload in enumerate(rows):
            try:
                self.excel_logger.append(**payload)
            except Exception:
                remaining = rows[index:]
                break
        if remaining:
            tmp = path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                for payload in remaining:
                    f.write(json.dumps(payload, ensure_ascii=False) + "\n")
            os.replace(tmp, path)
        else:
            os.remove(path)

    def _get_today_dist_counts(self):
        counts = {}
        if "LOGS" not in self.dirs:
            return counts
        today_str = datetime.datetime.now().strftime(DATE_FMT)
        log_file = os.path.join(self.dirs["LOGS"], f"操作日志_{today_str}.xlsx")

        if not os.path.exists(log_file):
            return counts

        try:
            from openpyxl import load_workbook
            wb = load_workbook(log_file, read_only=True, data_only=False)
            sheet = wb["明细"]
            for row in sheet.iter_rows(min_row=2, values_only=True):
                if row[1] == ACTION_DIST and row[10] == RESULT_SUCCESS:
                    amount = int(row[7] or 0) or int(row[8] or 0)
                    counts[row[2]] = counts.get(row[2], 0) + amount
            wb.close()
        except (OSError, ValueError, KeyError) as e:
            self.log(f"⚠️ 统计解析失败: {e}")
        return counts

    def _categories_path(self):
        return os.path.join(self.dirs["SYSTEM"], RECOVERY_CATEGORIES_FILE)

    def get_recovery_categories(self):
        path = self._categories_path()
        if not os.path.exists(path):
            return {}
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            return {str(k): sorted({str(v) for v in values}) for k, values in data.items()}
        except (OSError, json.JSONDecodeError, AttributeError, TypeError):
            return {}

    @staticmethod
    def _valid_category_name(name):
        return bool(
            name and name.strip() == name and name not in (".", "..")
            and not re.search(r'[<>:"/\\|?*]', name)
            and not re.match(RE_BATCH_ID, name)
            and not re.match(RE_BATCH_ABANDONED, name)
        )

    def add_recovery_category(self, level1, level2=""):
        if not self._valid_category_name(level1) or (level2 and not self._valid_category_name(level2)):
            return False, "类目名称包含非法字符"
        data = self.get_recovery_categories()
        parts = (level1, level2) if level2 else (level1,)
        for user in self.get_users():
            for root in (USER_TODO, USER_DONE, USER_REWORK):
                target = os.path.join(self.get_user_path(user), root, *parts)
                if self._unmarked_nonempty_dir(target):
                    return False, f"目录与现有任务同名，不能创建类目: {'/'.join(parts)}"
        data.setdefault(level1, [])
        if level2 and level2 not in data[level1]:
            data[level1].append(level2)
            data[level1].sort()
        try:
            self._save_recovery_categories(data)
            self.sync_recovery_categories()
            return True, "类目已保存"
        except OSError as e:
            return False, str(e)

    def _save_recovery_categories(self, data):
        os.makedirs(self.dirs["SYSTEM"], exist_ok=True)
        tmp = self._categories_path() + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        os.replace(tmp, self._categories_path())

    def rename_recovery_category(self, old_level1, old_level2, new_level1, new_level2=""):
        if not self._valid_category_name(new_level1) or (new_level2 and not self._valid_category_name(new_level2)):
            return False, "类目名称包含非法字符"
        data = self.get_recovery_categories()
        if old_level1 not in data or (old_level2 and old_level2 not in data[old_level1]):
            return False, "原类目不存在"
        old_parts = (old_level1, old_level2) if old_level2 else (old_level1,)
        new_parts = (new_level1, new_level2) if new_level2 else (new_level1,)
        for user in self.get_users():
            for root in (USER_TODO, USER_DONE, USER_REWORK):
                src = os.path.join(self.get_user_path(user), root, *old_parts)
                dst = os.path.join(self.get_user_path(user), root, *new_parts)
                if os.path.exists(src) and os.path.abspath(src) != os.path.abspath(dst):
                    if os.path.exists(dst):
                        return False, f"目标类目已存在: {new_level1}/{new_level2}".rstrip("/")
        if old_level2:
            data[old_level1].remove(old_level2)
            data.setdefault(new_level1, []).append(new_level2)
            data[new_level1] = sorted(set(data[new_level1]))
        else:
            data[new_level1] = data.pop(old_level1)
        moved = []
        try:
            for user in self.get_users():
                for root in (USER_TODO, USER_DONE, USER_REWORK):
                    src = os.path.join(self.get_user_path(user), root, *old_parts)
                    dst = os.path.join(self.get_user_path(user), root, *new_parts)
                    if os.path.exists(src) and os.path.abspath(src) != os.path.abspath(dst):
                        os.makedirs(os.path.dirname(dst), exist_ok=True)
                        os.rename(src, dst)
                        moved.append((src, dst))
            self._save_recovery_categories(data)
            return True, "类目已重命名"
        except OSError as e:
            for src, dst in reversed(moved):
                try:
                    if os.path.exists(dst) and not os.path.exists(src):
                        os.rename(dst, src)
                except OSError:
                    pass
            return False, str(e)

    def delete_recovery_category(self, level1, level2=""):
        data = self.get_recovery_categories()
        if level1 not in data or (level2 and level2 not in data[level1]):
            return False, "类目不存在"
        parts = (level1, level2) if level2 else (level1,)
        targets = [os.path.join(self.get_user_path(user), root, *parts)
                   for user in self.get_users() for root in (USER_TODO, USER_DONE, USER_REWORK)]
        for target in targets:
            if os.path.isdir(target):
                with os.scandir(target) as entries:
                    if any(entry.name != CATEGORY_MARKER_FILE for entry in entries):
                        return False, "类目中仍有任务，不能删除"
        try:
            for target in targets:
                if os.path.isdir(target):
                    marker = self._category_marker(target)
                    if os.path.isfile(marker):
                        os.remove(marker)
                    os.rmdir(target)
            if level2:
                data[level1].remove(level2)
            else:
                data.pop(level1)
            self._save_recovery_categories(data)
            return True, "类目已删除"
        except OSError as e:
            return False, str(e)

    def sync_recovery_categories(self):
        for user in self.get_users():
            self._sync_user_categories(user)

    def _sync_user_categories(self, user):
        base = self.get_user_path(user)
        for root in (USER_TODO, USER_DONE, USER_REWORK):
            for level1, children in self.get_recovery_categories().items():
                level1_path = os.path.join(base, root, level1)
                self._ensure_category_dir(level1_path)
                for level2 in children:
                    self._ensure_category_dir(os.path.join(level1_path, level2))

    @staticmethod
    def _category_marker(path):
        return os.path.join(path, CATEGORY_MARKER_FILE)

    def _ensure_category_dir(self, path):
        if self._unmarked_nonempty_dir(path):
            return False
        os.makedirs(path, exist_ok=True)
        marker = self._category_marker(path)
        if not os.path.exists(marker):
            with open(marker, "w", encoding="utf-8") as f:
                f.write("DataGuard v1.8 category")
        return True

    def _unmarked_nonempty_dir(self, path):
        if not os.path.isdir(path) or os.path.isfile(self._category_marker(path)):
            return False
        with os.scandir(path) as entries:
            return any(entry.name != CATEGORY_MARKER_FILE for entry in entries)

    def _is_category_dir(self, path, name, configured_names):
        return name in configured_names and os.path.isfile(self._category_marker(path))

    @staticmethod
    def _category_parts(recovery_path):
        parts = tuple(p for p in (recovery_path or ()) if p)
        return (parts[0] if parts else "未分类", parts[1] if len(parts) > 1 else "-")

    def get_users(self):
        if not os.path.exists(self.dirs["DIST"]):
            return []
        return sorted([d for d in os.listdir(self.dirs["DIST"]) if os.path.isdir(os.path.join(self.dirs["DIST"], d))])

    def get_teams(self):
        users = self.get_users()
        teams = set()
        for u in users:
            match = re.match(RE_TEAM_TAG, u)
            if match:
                teams.add(match.group(1))
        return sorted(list(teams))

    def get_raw_categories(self):
        if not os.path.exists(self.dirs["RAW"]):
            return []
        try:
            return sorted([d for d in os.listdir(self.dirs["RAW"]) if os.path.isdir(os.path.join(self.dirs["RAW"], d))])
        except OSError:
            return []

    def _batch_has_distributable_content(self, batch_path):
        """Return True when a batch contains a valid task folder or image."""
        try:
            names = os.listdir(batch_path)
        except OSError:
            return False

        for name in names:
            full = os.path.join(batch_path, name)
            if os.path.isfile(full) and os.path.splitext(name)[1].lower() in IMAGE_EXTENSIONS:
                return True
            if os.path.isdir(full) and re.match(RE_BATCH_ID, name):
                return True
            if os.path.isdir(full) and re.match(RE_GROUP_NAME, name):
                group_type = self.get_group_type(full)
                if self.get_items_in_group(full, group_type):
                    return True
        return False

    def get_batches_by_category(self, category, filter_empty=False):
        cat_path = os.path.join(self.dirs["RAW"], category)
        if not os.path.exists(cat_path):
            return []
        try:
            all_batches = [f for f in os.listdir(cat_path) if os.path.isdir(os.path.join(cat_path, f))]
            if not filter_empty:
                return sorted(all_batches, reverse=True)
            valid_batches = [
                batch for batch in all_batches
                if self._batch_has_distributable_content(os.path.join(cat_path, batch))
            ]
            return sorted(valid_batches, reverse=True)
        except OSError as e:
            self.log(f"⚠️ 读取批次失败: {e}")
            return []

    def get_raw_files(self, category, batch_name):
        batch_path = os.path.join(self.dirs["RAW"], category, batch_name)
        if not os.path.exists(batch_path):
            return []
        return sorted([f for f in os.listdir(batch_path) if os.path.isdir(os.path.join(batch_path, f))])

    def get_groups(self, category, batch_name):
        """获取批次下的分组列表，返回 [(分组名, 类型, 条目数), ...]"""
        batch_path = os.path.join(self.dirs["RAW"], category, batch_name)
        if not os.path.exists(batch_path):
            return []
        groups = []
        for name in sorted(os.listdir(batch_path)):
            full = os.path.join(batch_path, name)
            if not os.path.isdir(full):
                continue
            if not re.match(RE_GROUP_NAME, name):
                continue
            gtype = self.get_group_type(full)
            count = len(self.get_items_in_group(full, gtype))
            groups.append((name, gtype, count))
        return groups

    def get_group_type(self, group_path):
        """判定分组类型"""
        try:
            items = os.listdir(group_path)
        except OSError:
            return GROUP_TYPE_EMPTY
        # 过滤系统隐藏文件（.DS_Store、Thumbs.db 等）
        items = [i for i in items if not i.startswith('.') and i.lower() not in ('thumbs.db', 'desktop.ini')]
        if not items:
            return GROUP_TYPE_EMPTY
        dirs = []
        files = []
        for item in items:
            full = os.path.join(group_path, item)
            if os.path.isdir(full):
                dirs.append(item)
            else:
                files.append(item)
        has_folders = any(re.match(RE_BATCH_ID, d) for d in dirs)
        has_images = any(os.path.splitext(f)[1].lower() in IMAGE_EXTENSIONS for f in files)
        if has_folders and not has_images and not files:
            return GROUP_TYPE_FOLDER
        if has_images and not dirs:
            return GROUP_TYPE_IMAGE
        if has_folders or has_images:
            group_name = os.path.basename(group_path)
            self.log(f"⚠️ 分组 {group_name} 内容混合，无法分发（请整理后重试）")
            return GROUP_TYPE_MIXED
        return GROUP_TYPE_EMPTY

    def get_items_in_group(self, group_path, group_type):
        """获取分组内可发送条目列表"""
        try:
            items = os.listdir(group_path)
        except OSError:
            return []
        # 过滤系统隐藏文件
        items = [i for i in items if not i.startswith('.') and i.lower() not in ('thumbs.db', 'desktop.ini')]
        if group_type == GROUP_TYPE_FOLDER:
            return sorted([d for d in items if os.path.isdir(os.path.join(group_path, d)) and re.match(RE_BATCH_ID, d)])
        elif group_type == GROUP_TYPE_IMAGE:
            return sorted([f for f in items if os.path.isfile(os.path.join(group_path, f)) and os.path.splitext(f)[1].lower() in IMAGE_EXTENSIONS])
        return []

    def has_groups(self, category, batch_name):
        """判断批次下是否存在分组"""
        batch_path = os.path.join(self.dirs["RAW"], category, batch_name)
        if not os.path.exists(batch_path):
            return False
        try:
            for name in os.listdir(batch_path):
                if os.path.isdir(os.path.join(batch_path, name)) and re.match(RE_GROUP_NAME, name):
                    return True
        except OSError:
            pass
        return False

    def get_ungrouped_items(self, category, batch_name):
        """获取批次下未分组的八位数文件夹（散落在批次根目录的）"""
        batch_path = os.path.join(self.dirs["RAW"], category, batch_name)
        if not os.path.exists(batch_path):
            return []
        items = []
        try:
            for name in os.listdir(batch_path):
                full = os.path.join(batch_path, name)
                if os.path.isdir(full) and re.match(RE_BATCH_ID, name):
                    items.append(name)
        except OSError:
            pass
        return sorted(items)

    def get_ungrouped_images(self, category, batch_name):
        """获取批次下未分组的散落图片（不在任何分组中的图片文件）"""
        batch_path = os.path.join(self.dirs["RAW"], category, batch_name)
        if not os.path.exists(batch_path):
            return []
        items = []
        try:
            for name in os.listdir(batch_path):
                full = os.path.join(batch_path, name)
                if os.path.isfile(full) and os.path.splitext(name)[1].lower() in IMAGE_EXTENSIONS:
                    items.append(name)
        except OSError:
            pass
        return sorted(items)

    def create_group(self, category, batch_name, group_inner_name, group_type, move_existing=True):
        """创建新分组，返回 (成功, 消息, 分组名)"""
        if not group_inner_name:
            return False, "分组名不能为空", ""
        if not re.match(RE_GROUP_INNER, group_inner_name):
            return False, "分组名仅允许中文、英文、数字、下划线", ""
        group_name = f"【{group_inner_name}】"
        batch_path = os.path.join(self.dirs["RAW"], category, batch_name)
        if not os.path.exists(batch_path):
            return False, "批次路径不存在", ""
        group_path = os.path.join(batch_path, group_name)
        if os.path.exists(group_path):
            return False, f"分组 {group_name} 已存在", ""
        try:
            os.makedirs(group_path)
        except OSError as e:
            return False, f"创建失败: {e}", ""
        # 自动收纳批次根目录下未分组的素材
        moved = 0
        if move_existing:
            try:
                for item in os.listdir(batch_path):
                    full = os.path.join(batch_path, item)
                    if item == group_name:
                        continue
                    # 跳过已有的分组（【xxx】格式）
                    if os.path.isdir(full) and re.match(RE_GROUP_NAME, item):
                        continue
                    # 文件夹组：收纳八位数文件夹
                    if group_type == GROUP_TYPE_FOLDER and os.path.isdir(full) and re.match(RE_BATCH_ID, item):
                        dst = os.path.join(group_path, item)
                        if not os.path.exists(dst):
                            shutil.move(full, dst)
                            moved += 1
                    # 图片组：收纳散落图片文件
                    elif group_type == GROUP_TYPE_IMAGE and os.path.isfile(full) and os.path.splitext(item)[1].lower() in IMAGE_EXTENSIONS:
                        dst = os.path.join(group_path, item)
                        if not os.path.exists(dst):
                            shutil.move(full, dst)
                            moved += 1
            except OSError as e:
                self.log(f"⚠️ 自动收纳失败: {e}")
        msg_extra = f"，收纳 {moved} 个素材" if moved > 0 else ""
        self.log(f"✅ 创建分组: {group_name} ({group_type}){msg_extra}")
        return True, f"分组 {group_name} 创建成功{msg_extra}", group_name

    def delete_group(self, category, batch_name, group_name):
        """删除分组，将组内素材退回批次根目录，返回 (成功, 消息)"""
        batch_path = os.path.join(self.dirs["RAW"], category, batch_name)
        group_path = os.path.join(batch_path, group_name)
        if not os.path.exists(group_path):
            return False, "分组不存在"
        try:
            items = os.listdir(group_path)
        except OSError as e:
            return False, f"读取分组失败: {e}"
        # 过滤系统隐藏文件
        items = [i for i in items if not i.startswith('.') and i.lower() not in ('thumbs.db', 'desktop.ini')]
        # 将组内素材移回批次根目录
        moved = 0
        for item in items:
            src = os.path.join(group_path, item)
            dst = os.path.join(batch_path, item)
            try:
                if os.path.exists(dst):
                    # 目标已存在，加序号
                    base, ext = os.path.splitext(item)
                    seq = 1
                    while os.path.exists(os.path.join(batch_path, f"{base}_{seq}{ext}")):
                        seq += 1
                    dst = os.path.join(batch_path, f"{base}_{seq}{ext}")
                shutil.move(src, dst)
                moved += 1
            except OSError as e:
                self.log(f"⚠️ 退回失败 {item}: {e}")
        # 删除空的分组目录
        try:
            os.rmdir(group_path)
            self.log(f"🗑️ 删除分组: {group_name}（退回 {moved} 个素材）")
            return True, f"分组 {group_name} 已删除，{moved} 个素材退回批次根目录"
        except OSError as e:
            return False, f"删除分组目录失败: {e}"

    def rename_group(self, category, batch_name, old_group_name, new_inner_name):
        """分组重命名，返回 (成功, 消息)"""
        if not new_inner_name:
            return False, "新名称不能为空"
        if not re.match(RE_GROUP_INNER, new_inner_name):
            return False, "名称仅允许中文、英文、数字、下划线"
        new_group_name = f"【{new_inner_name}】"
        batch_path = os.path.join(self.dirs["RAW"], category, batch_name)
        old_path = os.path.join(batch_path, old_group_name)
        new_path = os.path.join(batch_path, new_group_name)
        if not os.path.exists(old_path):
            return False, "原分组不存在"
        if os.path.exists(new_path):
            return False, f"分组 {new_group_name} 已存在"
        try:
            os.rename(old_path, new_path)
            self.log(f"✏️ 重命名分组: {old_group_name} → {new_group_name}")
            return True, f"重命名为 {new_group_name}"
        except OSError as e:
            return False, f"重命名失败: {e}"

    def distribute_image_group(self, user_id, category, batch_name, group_name, image_list,
                               gui_callback=None, msg_queue=None, cancel_flag=None,
                               recovery_path=()):
        """图片组专用分发：将图片打包为文件夹后发送到标注员 To_Do"""
        if not image_list:
            return 0, 0, ""
        # group_name 为 None 表示未分组图片，直接在批次根目录
        if group_name:
            src_root = os.path.join(self.dirs["RAW"], category, batch_name, group_name)
        else:
            src_root = os.path.join(self.dirs["RAW"], category, batch_name)
        target_todo = os.path.join(self.dirs["DIST"], user_id, USER_TODO, *(recovery_path or ()))
        if not os.path.exists(target_todo):
            os.makedirs(target_todo)
        inner_name = group_name.strip("【】") if group_name else "未分组图片"
        # 在 To_Do 下创建以分组名命名的文件夹
        pack_folder = inner_name
        pack_path = os.path.join(target_todo, pack_folder)
        # 如果已存在同名文件夹，加序号
        if os.path.exists(pack_path):
            seq = 1
            while os.path.exists(os.path.join(target_todo, f"{inner_name}_{seq}")):
                seq += 1
            pack_folder = f"{inner_name}_{seq}"
            pack_path = os.path.join(target_todo, pack_folder)
        os.makedirs(pack_path)
        count = 0
        failed = 0
        total = len(image_list)
        for idx, img_name in enumerate(image_list):
            if cancel_flag and cancel_flag():
                self.log("⏹️ 操作已取消")
                break
            src = os.path.join(src_root, img_name)
            dst = os.path.join(pack_path, img_name)
            ok, msg = retry_move(src, dst, msg_queue=msg_queue)
            if ok:
                count += 1
            else:
                self.log(f"❌ 传送失败 {img_name}: {msg}")
                failed += 1
            self._emit_progress(msg_queue, gui_callback, idx + 1, total)
        if count > 0:
            self.write_csv_log(
                ACTION_DIST, user_id, pack_folder, STATUS_NORMAL, RESULT_SUCCESS,
                f"[{category}]-{batch_name}-{group_name or '未分组'}",
                recovery_path=recovery_path, image_count=count, task_count=1,
                content_type="图片包",
            )
            self.log(f"🔮 图片组传送 {group_name or '未分组图片'}({count}张) -> {user_id}/{pack_folder}")
            # 清理空的源分组目录（仅限真正的分组，未分组图片不清除批次目录）
            if group_name:
                self._cleanup_empty_group(src_root)
        if failed > 0:
            self.write_csv_log(
                ACTION_DIST, user_id, pack_folder, STATUS_NORMAL, RESULT_FAIL,
                f"{failed}张失败", recovery_path=recovery_path,
                image_count=failed, task_count=1, content_type="图片包",
            )
        self._stats_cache = None
        return count, failed, pack_folder

    def _cleanup_empty_group(self, group_path):
        """如果分组目录为空（忽略系统隐藏文件），自动删除"""
        try:
            if os.path.exists(group_path):
                remaining = [i for i in os.listdir(group_path) if not i.startswith('.') and i.lower() not in ('thumbs.db', 'desktop.ini')]
                if not remaining:
                    # 先清理隐藏文件再 rmdir
                    for f in os.listdir(group_path):
                        try:
                            os.remove(os.path.join(group_path, f))
                        except OSError:
                            pass
                    os.rmdir(group_path)
                    self.log(f"🧹 已清理空分组: {os.path.basename(group_path)}")
        except OSError:
            pass

    def get_category_total_count(self, category):
        cat_path = os.path.join(self.dirs["RAW"], category)
        if not os.path.exists(cat_path):
            return 0
        total = 0
        try:
            batches = [d for d in os.listdir(cat_path) if os.path.isdir(os.path.join(cat_path, d))]
            for batch in batches:
                batch_path = os.path.join(cat_path, batch)
                total += self._count_batch_items(batch_path)
        except OSError:
            pass
        return total

    def get_total_raw_count(self):
        if not os.path.exists(self.dirs["RAW"]):
            return 0
        total = 0
        try:
            for cat in os.listdir(self.dirs["RAW"]):
                cat_path = os.path.join(self.dirs["RAW"], cat)
                if os.path.isdir(cat_path):
                    for batch in os.listdir(cat_path):
                        path = os.path.join(cat_path, batch)
                        if os.path.isdir(path):
                            total += self._count_batch_items(path)
        except OSError:
            pass
        return total

    def _count_batch_items(self, batch_path):
        """统计批次内的可发送条目数（兼容有/无分组层）"""
        count = 0
        try:
            for name in os.listdir(batch_path):
                full = os.path.join(batch_path, name)
                if os.path.isdir(full):
                    if re.match(RE_GROUP_NAME, name):
                        # 分组：统计分组内的条目
                        gtype = self.get_group_type(full)
                        count += len(self.get_items_in_group(full, gtype))
                    elif re.match(RE_BATCH_ID, name):
                        # 未分组的八位数文件夹
                        count += 1
                elif os.path.isfile(full) and os.path.splitext(name)[1].lower() in IMAGE_EXTENSIONS:
                    # 未分组的散落图片
                    count += 1
        except OSError:
            pass
        return count

    def get_done_stats(self):
        now = time.time()
        if self._stats_cache is not None and now - self._stats_cache_ts < 2.0:
            return self._stats_cache
        stats = []
        users = self.get_users()
        dist_data = self._get_today_dist_counts()

        for user in users:
            done_path = os.path.join(self.dirs["DIST"], user, USER_DONE)
            rework_path = os.path.join(self.dirs["DIST"], user, USER_REWORK)
            todo_path = os.path.join(self.dirs["DIST"], user, USER_TODO)
            normal = 0
            abandoned = 0
            rework_count = 0
            pending = 0
            if os.path.exists(done_path):
                try:
                    for _, f, _ in self._iter_classified_tasks(done_path):
                        if re.match(RE_BATCH_ABANDONED, f):
                            abandoned += 1
                        else:
                            normal += 1
                except OSError:
                    pass
            if os.path.exists(rework_path):
                try:
                    rework_count = sum(1 for _ in self._iter_classified_tasks(rework_path))
                except OSError:
                    pass
            if os.path.exists(todo_path):
                try:
                    pending = sum(1 for _ in self._iter_classified_tasks(todo_path))
                except OSError:
                    pass
            distributed_today = dist_data.get(user, 0)
            stats.append({
                "user": user,
                "distributed_today": distributed_today,
                "normal": normal,
                "abandoned": abandoned,
                "rework": rework_count,
                "pending": pending,
                "total_done": normal + abandoned + rework_count,
            })
        self._stats_cache = stats
        self._stats_cache_ts = now
        return stats

    def _iter_classified_tasks(self, root):
        """遍历根目录、一级类目和二级类目中的任务目录。"""
        if not os.path.isdir(root):
            return
        categories = self.get_recovery_categories()
        for level1 in os.listdir(root):
            path1 = os.path.join(root, level1)
            if not os.path.isdir(path1):
                continue
            if re.match(RE_BATCH_ID, level1) or re.match(RE_BATCH_ABANDONED, level1) or not self._is_category_dir(path1, level1, categories):
                yield (), level1, path1
                continue
            for level2 in os.listdir(path1):
                path2 = os.path.join(path1, level2)
                if not os.path.isdir(path2):
                    continue
                if re.match(RE_BATCH_ID, level2) or re.match(RE_BATCH_ABANDONED, level2) or not self._is_category_dir(path2, level2, categories[level1]):
                    yield (level1,), level2, path2
                    continue
                for task_name in os.listdir(path2):
                    task_path = os.path.join(path2, task_name)
                    if os.path.isdir(task_path):
                        yield (level1, level2), task_name, task_path

    def get_history_dates(self):
        dates = set()
        path_new = os.path.join(self.dirs["QC"], QC_NEW)
        if os.path.exists(path_new):
            dates.update([d for d in os.listdir(path_new) if re.match(RE_DATE_DIR, d)])
        path_rework = os.path.join(self.dirs["QC"], QC_REWORK)
        if os.path.exists(path_rework):
            dates.update([d for d in os.listdir(path_rework) if re.match(RE_DATE_DIR, d)])
        return sorted(list(dates), reverse=True)

    def get_history_stats(self, date_str):
        abandoned_dir = os.path.join(self.dirs["QC"], QC_ABANDONED, date_str)
        abandoned_count = 0
        if os.path.exists(abandoned_dir):
            try:
                abandoned_count = sum(
                    1 for current, dirs, _ in os.walk(abandoned_dir)
                    for name in dirs if re.match(RE_BATCH_ABANDONED, name)
                )
            except OSError:
                pass
        new_dir_root = os.path.join(self.dirs["QC"], QC_NEW, date_str)
        rework_dir_root = os.path.join(self.dirs["QC"], QC_REWORK, date_str)
        all_users = set(self.get_users())
        user_breakdown = []
        total_new = 0
        total_rework = 0
        for user in all_users:
            u_new_count = 0
            u_rework_count = 0
            u_new_count = sum(self._count_immediate_dirs(path) for path in self._find_user_result_dirs(new_dir_root, user))
            u_rework_count = sum(self._count_immediate_dirs(path) for path in self._find_user_result_dirs(rework_dir_root, user))
            if u_new_count == 0 and u_rework_count == 0:
                continue
            user_breakdown.append({"user": user, "new": u_new_count, "rework": u_rework_count, "subtotal": u_new_count + u_rework_count})
            total_new += u_new_count
            total_rework += u_rework_count
        return {
            "date": date_str,
            "abandoned": abandoned_count,
            "total_new": total_new,
            "total_rework": total_rework,
            "grand_total": total_new + total_rework,
            "user_breakdown": user_breakdown,
        }

    def get_users_in_history_date_by_mode(self, date_str, mode="new"):
        folder = QC_NEW if mode == "new" else QC_REWORK
        target_dir = os.path.join(self.dirs["QC"], folder, date_str)
        if not os.path.exists(target_dir):
            return []
        return [user for user in self.get_users() if self._find_user_result_dirs(target_dir, user)]

    def get_qa_task_count_by_mode(self, date_str, user, mode="new"):
        folder = QC_NEW if mode == "new" else QC_REWORK
        root = os.path.join(self.dirs["QC"], folder, date_str)
        return sum(self._count_immediate_dirs(path) for path in self._find_user_result_dirs(root, user))

    @staticmethod
    def _count_immediate_dirs(path):
        try:
            return sum(1 for name in os.listdir(path) if os.path.isdir(os.path.join(path, name)))
        except OSError:
            return 0

    @staticmethod
    def _find_user_result_dirs(root, user):
        matches = []
        if not os.path.isdir(root):
            return matches
        for current, dirs, _ in os.walk(root):
            if os.path.basename(current) == user:
                matches.append(current)
                dirs[:] = []
        return matches

    def distribute_specific(self, user_id, category, batch_name, folder_list,
                            gui_callback=None, msg_queue=None, cancel_flag=None,
                            recovery_path=()):
        src_root = os.path.join(self.dirs["RAW"], category, batch_name)
        target_todo = os.path.join(self.dirs["DIST"], user_id, USER_TODO, *(recovery_path or ()))
        if not os.path.exists(target_todo):
            os.makedirs(target_todo)
        count = 0
        failed = 0
        total = len(folder_list)
        for idx, folder_name in enumerate(folder_list):
            if cancel_flag and cancel_flag():
                self.log("⏹️ 操作已取消")
                break
            src = os.path.join(src_root, folder_name)
            # 目标路径扁平化：只用八位数文件夹名，不带分组目录前缀
            bare_name = os.path.basename(folder_name)
            dst = os.path.join(target_todo, bare_name)
            ok, msg = retry_move(src, dst, msg_queue=msg_queue)
            if ok:
                self.write_csv_log(
                    ACTION_DIST, user_id, bare_name, STATUS_NORMAL, RESULT_SUCCESS,
                    f"[{category}]-{batch_name}", recovery_path=recovery_path,
                )
                self.log(f"🔮 传送 {bare_name} -> {user_id}")
                count += 1
            else:
                self.log(f"❌ 传送失败 {bare_name}: {msg}")
                self.write_csv_log(
                    ACTION_DIST, user_id, bare_name, STATUS_NORMAL, RESULT_FAIL,
                    msg, recovery_path=recovery_path,
                )
                failed += 1
            # 进度通知：优先用 queue，其次用 gui_callback
            self._emit_progress(msg_queue, gui_callback, idx + 1, total)
        self._stats_cache = None
        return count, failed, "传送完毕"

    def _emit_progress(self, msg_queue, gui_callback, current, total):
        """发送进度通知（优先 queue，其次 callback）"""
        if msg_queue:
            msg_queue.put(("progress", (current, total)))
        elif gui_callback:
            gui_callback(current, total)

    def _safe_move(self, src, dst, msg_queue=None):
        """带重试的安全移动，替代原有的 _safe_move"""
        return retry_move(src, dst, msg_queue=msg_queue)

    def _separate_psd_files(self, src_batch_path, user, batch_name, msg_queue=None):
        if not os.path.exists(src_batch_path):
            self.log(f"⚠️ PSD分离跳过: 路径不存在 {src_batch_path}")
            return 0

        today_str = datetime.datetime.now().strftime(DATE_FMT)
        psd_target_root = os.path.join(self.dirs["PSD_BACKUP"], today_str, user, batch_name)

        psd_entries = []
        for current, _, files in os.walk(src_batch_path):
            for filename in files:
                if filename.lower().endswith(".psd"):
                    src_psd = os.path.join(current, filename)
                    relative_path = os.path.relpath(src_psd, src_batch_path)
                    psd_entries.append((src_psd, relative_path))

        if not psd_entries:
            self.log(f"⚠️ PSD分离跳过: {batch_name} 无PSD文件")
            return 0

        psd_count = 0
        for src_psd, relative_path in psd_entries:
            dst_psd = os.path.join(psd_target_root, relative_path)
            os.makedirs(os.path.dirname(dst_psd), exist_ok=True)
            ok, msg = retry_move(src_psd, dst_psd, msg_queue=msg_queue)
            if ok:
                psd_count += 1
                self.log(f"✅ PSD分离: {relative_path}")
            else:
                self.log(f"⚠️ PSD移动失败: {relative_path} - {msg}")

        if psd_count > 0:
            self.log(f"[PSD分离] {batch_name} 分离 {psd_count} 个PSD文件")

        return psd_count

    def _harvest_done(self, user, qc_new_root, qc_abandoned_dir, today_str, separate_psd, msg_queue, cancel_flag):
        """回收用户的 Done 目录，返回 (new_done, abandoned, skipped)"""
        cnt_new = 0
        cnt_abandoned = 0
        cnt_skipped = 0
        done_path = os.path.join(self.dirs["DIST"], user, USER_DONE)
        if not os.path.exists(done_path):
            return cnt_new, cnt_abandoned, cnt_skipped
        try:
            for recovery_path, folder_name, src in list(self._iter_classified_tasks(done_path)):
                if cancel_flag and cancel_flag():
                    break
                if re.match(RE_BATCH_ABANDONED, folder_name):
                    dst = os.path.join(qc_abandoned_dir, *recovery_path, user, folder_name)
                    status = STATUS_ABANDONED_NEW
                    is_waste = True
                else:
                    dst = os.path.join(qc_new_root, *recovery_path, user, folder_name)
                    status = STATUS_REWORK_NEW
                    is_waste = False
                ok, msg = self._safe_move(src, dst, msg_queue=msg_queue)
                if ok:
                    self.write_csv_log(
                        ACTION_HARVEST_NEW, user, folder_name, status,
                        RESULT_SUCCESS, recovery_path=recovery_path,
                    )
                    if is_waste:
                        cnt_abandoned += 1
                    else:
                        cnt_new += 1
                        if separate_psd:
                            psd_count = self._separate_psd_files(dst, user, folder_name, msg_queue=msg_queue)
                            if psd_count > 0:
                                psd_path = os.path.join(self.dirs["PSD_BACKUP"], today_str, user)
                                self.log(f"📦 PSD备份目录: {psd_path}")
                else:
                    self.log(f"❌ Done回收失败 {folder_name}: {msg}")
                    self.write_csv_log(
                        ACTION_HARVEST_NEW, user, folder_name, status,
                        RESULT_FAIL, msg, recovery_path=recovery_path,
                    )
                    cnt_skipped += 1
        except OSError as e:
            self.log(f"⚠️ 扫描 {user} Done 出错: {e}")
        return cnt_new, cnt_abandoned, cnt_skipped

    def _harvest_rework(self, user, qc_rework_root, qc_abandoned_dir, today_str, separate_psd, msg_queue, cancel_flag):
        """回收用户的返修目录，返回 (rework_done, abandoned, skipped)"""
        cnt_rework = 0
        cnt_abandoned = 0
        cnt_skipped = 0
        rework_src_dir = os.path.join(self.dirs["DIST"], user, USER_REWORK)
        if not os.path.exists(rework_src_dir):
            return cnt_rework, cnt_abandoned, cnt_skipped
        try:
            rework_items = list(self._iter_classified_tasks(rework_src_dir))
            if not rework_items:
                return cnt_rework, cnt_abandoned, cnt_skipped
            for recovery_path, folder_name, src in rework_items:
                if cancel_flag and cancel_flag():
                    break
                if re.match(RE_BATCH_ABANDONED, folder_name):
                    dst = os.path.join(qc_abandoned_dir, *recovery_path, user, folder_name)
                    status = STATUS_ABANDONED_REWORK
                    is_waste = True
                else:
                    dst = os.path.join(qc_rework_root, *recovery_path, user, folder_name)
                    status = STATUS_REWORK_REWORK
                    is_waste = False
                ok, msg = self._safe_move(src, dst, msg_queue=msg_queue)
                if ok:
                    dest_desc = QC_ABANDONED if is_waste else QC_REWORK
                    self.write_csv_log(
                        ACTION_HARVEST_REWORK, user, folder_name, status,
                        RESULT_SUCCESS, f"存入{dest_desc}", recovery_path=recovery_path,
                    )
                    if is_waste:
                        cnt_abandoned += 1
                    else:
                        cnt_rework += 1
                        if separate_psd:
                            psd_count = self._separate_psd_files(dst, user, folder_name, msg_queue=msg_queue)
                            if psd_count > 0:
                                psd_path = os.path.join(self.dirs["PSD_BACKUP"], today_str, user)
                                self.log(f"📦 PSD备份目录: {psd_path}")
                else:
                    self.log(f"❌ 返修回收失败 {folder_name}: {msg}")
                    self.write_csv_log(
                        ACTION_HARVEST_REWORK, user, folder_name, status,
                        RESULT_FAIL, msg, recovery_path=recovery_path,
                    )
                    cnt_skipped += 1
        except OSError as e:
            self.log(f"⚠️ 扫描 {user} 返修出错: {e}")
        return cnt_rework, cnt_abandoned, cnt_skipped

    def _harvest_todo(self, user, recycle_dir, msg_queue, cancel_flag):
        """回收用户的 To_Do 目录，返回 recycle_count"""
        cnt_recycle = 0
        cnt_skipped = 0
        todo_path = os.path.join(self.dirs["DIST"], user, USER_TODO)
        if not os.path.exists(todo_path):
            return cnt_recycle, cnt_skipped
        try:
            for recovery_path, folder_name, src in list(self._iter_classified_tasks(todo_path)):
                if cancel_flag and cancel_flag():
                    break
                dst = os.path.join(recycle_dir, *recovery_path, user, folder_name)
                ok, msg = self._safe_move(src, dst, msg_queue=msg_queue)
                if ok:
                    self.write_csv_log(
                        ACTION_HARVEST_RECYCLE, user, folder_name, STATUS_RECYCLE,
                        RESULT_SUCCESS, recovery_path=recovery_path,
                    )
                    cnt_recycle += 1
                else:
                    self.log(f"❌ To_Do回收失败 {folder_name}: {msg}")
                    self.write_csv_log(
                        ACTION_HARVEST_RECYCLE, user, folder_name, STATUS_RECYCLE,
                        RESULT_FAIL, msg, recovery_path=recovery_path,
                    )
                    cnt_skipped += 1
        except OSError as e:
            self.log(f"⚠️ 回收 ToDo 出错: {e}")
        return cnt_recycle, cnt_skipped

    def harvest(self, target_user=None, collect_unfinished=True, gui_callback=None, separate_psd=True, msg_queue=None, cancel_flag=None):
        today_str = datetime.datetime.now().strftime(DATE_FMT)
        qc_new_root = os.path.join(self.dirs["QC"], QC_NEW, today_str)
        qc_rework_root = os.path.join(self.dirs["QC"], QC_REWORK, today_str)
        qc_abandoned_dir = os.path.join(self.dirs["QC"], QC_ABANDONED, today_str)
        recycle_batch_name = f"{today_str}_未完回收"
        recycle_dir = os.path.join(self.dirs["RAW"], recycle_batch_name)
        if not os.path.exists(qc_abandoned_dir):
            os.makedirs(qc_abandoned_dir)
        users = [target_user] if target_user else self.get_users()
        cnt_new = cnt_rework = cnt_abandoned = cnt_recycle = cnt_skipped = 0
        total_users = len(users) if users else 1
        for idx, user in enumerate(users):
            if cancel_flag and cancel_flag():
                self.log("⏹️ 操作已取消")
                break
            self.log(f"⚡ 扫描 {user} ...")
            self._emit_progress(msg_queue, gui_callback, idx + 1, total_users)
            n, a, s = self._harvest_done(user, qc_new_root, qc_abandoned_dir, today_str, separate_psd, msg_queue, cancel_flag)
            cnt_new += n; cnt_abandoned += a; cnt_skipped += s
            r, a2, s2 = self._harvest_rework(user, qc_rework_root, qc_abandoned_dir, today_str, separate_psd, msg_queue, cancel_flag)
            cnt_rework += r; cnt_abandoned += a2; cnt_skipped += s2
            if collect_unfinished:
                recycled, skipped = self._harvest_todo(user, recycle_dir, msg_queue, cancel_flag)
                cnt_recycle += recycled
                cnt_skipped += skipped
            self._emit_progress(msg_queue, gui_callback, idx + 1, total_users)
        if collect_unfinished and cnt_recycle == 0:
            try:
                if os.path.exists(recycle_dir) and not os.listdir(recycle_dir):
                    os.rmdir(recycle_dir)
                    recycle_batch_name = "无"
            except OSError:
                pass
        if not collect_unfinished:
            recycle_batch_name = "未启用"
        self._stats_cache = None
        return cnt_new, cnt_rework, cnt_abandoned, cnt_recycle, recycle_batch_name, cnt_skipped

    def _qa_source_dirs(self, source_date_str, source_user, mode="new"):
        """Return legacy and classified QC result directories for one source user."""
        folder_map = {"new": QC_NEW, "rework": QC_REWORK}
        src_root_folder = folder_map.get(mode, QC_NEW)
        date_root = os.path.join(self.dirs["QC"], src_root_folder, source_date_str)
        return date_root, self._find_user_result_dirs(date_root, source_user)

    def distribute_to_internal_qa(self, source_date_str, source_user, target_qa_user, mode="new", msg_queue=None, cancel_flag=None):
        date_root, source_dirs = self._qa_source_dirs(source_date_str, source_user, mode)
        if not source_dirs:
            return 0, f"[{source_user}] 无数据"

        task_entries = []
        try:
            for source_dir in source_dirs:
                relative_user_dir = os.path.relpath(source_dir, date_root)
                category_path = os.path.dirname(relative_user_dir)
                if category_path == ".":
                    category_path = ""
                for task_name in sorted(os.listdir(source_dir)):
                    task_path = os.path.join(source_dir, task_name)
                    if os.path.isdir(task_path):
                        task_entries.append((category_path, task_name, task_path))
        except OSError:
            return 0, "读取源目录失败"

        task_count = len(task_entries)
        if task_count == 0:
            return 0, f"[{source_user}] 数据为空"

        today_mmdd = datetime.datetime.now().strftime(DATE_MMDD)
        batch_folder_name = f"【{today_mmdd}下发待验收数据】"
        type_folder_name = QA_TYPE_NEW if mode == "new" else QA_TYPE_REWORK
        target_base_path = os.path.join(self.dirs["DIST"], target_qa_user, batch_folder_name, type_folder_name)
        os.makedirs(target_base_path, exist_ok=True)

        try:
            try:
                src_date_obj = datetime.datetime.strptime(source_date_str, DATE_FMT)
                src_mmdd = src_date_obj.strftime(DATE_MMDD)
            except ValueError:
                src_mmdd = source_date_str.replace("-", "")[-4:]
            desc_str = QA_DESC_NEW if mode == "new" else QA_DESC_REWORK
            final_packet_name = f"{src_mmdd}{source_user}完成的{desc_str}；（{task_count}条）"
            final_dst_path = os.path.join(target_base_path, final_packet_name)
            if os.path.exists(final_dst_path):
                return 0, f"目标已存在: {final_dst_path}"

            staging_path = final_dst_path + f".__building_{os.getpid()}_{time.time_ns()}"
            os.makedirs(staging_path)
            try:
                for category_path, task_name, task_path in task_entries:
                    if cancel_flag and cancel_flag():
                        return 0, "操作已取消"
                    destination_parent = os.path.join(staging_path, category_path) if category_path else staging_path
                    os.makedirs(destination_parent, exist_ok=True)
                    destination_task = os.path.join(destination_parent, task_name)
                    ok, msg = retry_copytree(task_path, destination_task, msg_queue=msg_queue)
                    if not ok:
                        return 0, msg
                os.replace(staging_path, final_dst_path)
            finally:
                if os.path.exists(staging_path):
                    shutil.rmtree(staging_path, ignore_errors=True)

            self.write_csv_log(ACTION_QA_DIST, target_qa_user, final_packet_name, f"来自{source_user}", RESULT_SUCCESS)
            self.log(f"🚀 下发成功: {source_user} -> {target_qa_user} | 📂 {final_packet_name}")
            return task_count, "成功"
        except OSError as e:
            self.log(f"❌ 复制失败: {e}")
            return 0, str(e)

    def get_log_files_list(self):
        if "LOGS" not in self.dirs or not os.path.exists(self.dirs["LOGS"]):
            return []
        log_files = []
        try:
            files = [f for f in os.listdir(self.dirs["LOGS"]) if f.endswith((".xlsx", ".csv"))]
            for f in files:
                full_path = os.path.join(self.dirs["LOGS"], f)
                date_match = re.search(RE_DATE_DIR, f)
                date_str = date_match.group(0) if date_match else "未知日期"
                size_kb = round(os.path.getsize(full_path) / 1024, 1)
                log_files.append({"date": date_str, "filename": f, "size": f"{size_kb} KB", "path": full_path})
            log_files.sort(key=lambda x: x["date"], reverse=True)
        except OSError as e:
            self.log(f"⚠️ 读取日志列表失败: {e}")
        return log_files
