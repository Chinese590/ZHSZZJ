# alchemy/constants.py
# 所有硬编码常量统一定义，其他模块通过 import 引用

import os

from alchemy.runtime import writable_path

# --- 目录名 ---
DIR_RAW = "01_Raw_Data"
DIR_DIST = "02_Distributed"
DIR_QC = "04_Quality_Check"
DIR_LOGS = "05_System_Logs"
DIR_TOOLS = "03_Tools"
DIR_STARTER_TOOLS = "Starter_Tools"
DIR_PSD_BACKUP = "PSD备份库"

# --- 用户子目录 ---
USER_DONE = "Done"
USER_REWORK = "【返修提交】"
USER_TODO = "To_Do"
USER_TOOLBOX = "Toolbox"

# --- QC 子目录 ---
QC_NEW = "1_新标数据"
QC_REWORK = "2_返修数据"
QC_ABANDONED = "_Abandoned_Pool"

# --- 默认分类 ---
DEFAULT_CATEGORIES = ["人体", "物体", "场景", "其他"]

# --- 日期/时间格式 ---
DATE_FMT = "%Y-%m-%d"
TIME_FMT = "%H:%M:%S"
DATE_MMDD = "%m%d"

# --- 正则模式 ---
RE_BATCH_ID = r'^\d{8}$'
RE_BATCH_ABANDONED = r'^\d{8}【废弃】$'
RE_DATE_DIR = r'\d{4}-\d{2}-\d{2}'
RE_TEAM_TAG = r'^(【.*?】)'
RE_GROUP_NAME = r'^【.*?】$'
RE_GROUP_INNER = r'^[\u4e00-\u9fa5a-zA-Z0-9_]+$'

# --- 分组类型 ---
GROUP_TYPE_FOLDER = "folder"
GROUP_TYPE_IMAGE = "image"
GROUP_TYPE_EMPTY = "empty"
GROUP_TYPE_MIXED = "mixed"

# --- 图片扩展名 ---
IMAGE_EXTENSIONS = {'.jpg', '.jpeg', '.png', '.bmp', '.webp', '.tiff', '.gif'}

# --- CSV 相关 ---
CSV_HEADERS = ["时间", "术式类型", "炼金师", "素材ID", "状态", "结果", "备注"]
CSV_LOG_PREFIX = "传送记录_"
CSV_ENCODINGS = ['utf-8-sig', 'gbk', 'utf-8']
RECOVERY_CATEGORIES_FILE = "回收类目.json"
CATEGORY_MARKER_FILE = ".dataguard_category"

# --- 操作类型字符串（CSV 日志用） ---
ACTION_DIST = "素材下发"
ACTION_HARVEST_NEW = "产物回收"
ACTION_HARVEST_REWORK = "返修回收"
ACTION_HARVEST_RECYCLE = "强制回收"
ACTION_QA_DIST = "样本下发"

# --- 状态/结果字符串（CSV 日志用） ---
STATUS_NORMAL = "常规素材"
STATUS_REWORK_NEW = "新标产物"
STATUS_REWORK_REWORK = "返修产物"
STATUS_ABANDONED_NEW = "新标废弃"
STATUS_ABANDONED_REWORK = "返修废弃"
STATUS_RECYCLE = "未完退回"
RESULT_SUCCESS = "成功"
RESULT_FAIL = "失败"

# --- QA 文件夹名 ---
QA_TYPE_NEW = "【新标】"
QA_TYPE_REWORK = "【返修】"
QA_DESC_NEW = "（新标）待初验的数据"
QA_DESC_REWORK = "（返修）待二验的数据"

# --- UI 常量 ---
UI_THEME = "flatly"
UI_GEOMETRY = "1000x950"
UI_FONT_MONO = ("Consolas", 10)
UI_FONT_CJK = ("Microsoft YaHei", 10)
UI_BG = "#F4F7FB"
UI_SURFACE = "#FFFFFF"
UI_PRIMARY = "#1769AA"
UI_ACCENT = "#2F80ED"
UI_BORDER = "#D7E1EE"
UI_TEXT = "#1F2937"
UI_MUTED = "#5F6B7A"
UI_LIST_SELECTION = "#DCEBFA"
CONFIG_FILENAME = writable_path("alchemy_config.json")
APP_TITLE = "DataGuard 管理员端 v1.9.22"
VERSION_MSG = "✨ DataGuard v1.9.22 已就绪"

# --- 重试配置 ---
MAX_RETRIES = 3
RETRY_DELAY = 1.0

# --- 队列消息类型 ---
MSG_PROGRESS = "progress"
MSG_LOG = "log"
MSG_DONE = "done"
MSG_ERROR = "error"


def build_dirs(root_path: str) -> dict:
    """根据根路径构建所有目录路径字典"""
    return {
        "RAW": os.path.join(root_path, DIR_RAW),
        "DIST": os.path.join(root_path, DIR_DIST),
        "QC": os.path.join(root_path, DIR_QC),
        "LOGS": os.path.join(root_path, DIR_LOGS),
        "SYSTEM": os.path.join(root_path, DIR_TOOLS),
        "NEWBIE_TOOLS": os.path.join(root_path, DIR_TOOLS, DIR_STARTER_TOOLS),
        "PSD_BACKUP": os.path.join(root_path, DIR_QC, DIR_PSD_BACKUP),
    }
