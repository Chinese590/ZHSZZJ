# alchemy/worker.py
# 后台任务执行器 — 桥接后台线程与 UI 主线程

import threading
import queue

from alchemy.constants import MSG_PROGRESS, MSG_LOG, MSG_DONE, MSG_ERROR


class TaskWorker:
    """管理后台线程生命周期，通过 queue 与 UI 主线程通信"""

    def __init__(self, root, on_progress=None, on_log=None, on_complete=None, on_error=None):
        self.root = root
        self._queue = queue.Queue()
        self._running = False
        self._cancel_flag = False
        self.on_progress = on_progress or (lambda data: None)
        self.on_log = on_log or (lambda msg: None)
        self.on_complete = on_complete or (lambda result: None)
        self.on_error = on_error or (lambda msg: None)

    def start(self, task_func, *args, **kwargs):
        """启动后台任务。task_func 在后台线程执行，通过 msg_queue 发送消息。"""
        if self._running:
            return
        self._running = True
        self._cancel_flag = False
        kwargs['msg_queue'] = self._queue
        kwargs['cancel_flag'] = self._get_cancel_flag
        thread = threading.Thread(
            target=self._run, args=(task_func, args), kwargs=kwargs, daemon=True
        )
        thread.start()
        self._poll_queue()

    def cancel(self):
        """请求取消当前任务"""
        self._cancel_flag = True

    def is_running(self):
        return self._running

    def _get_cancel_flag(self):
        """供后台线程检查是否被取消"""
        return self._cancel_flag

    def _run(self, task_func, args, **kwargs):
        """后台线程入口"""
        try:
            result = task_func(*args, **kwargs)
            self._queue.put((MSG_DONE, result))
        except Exception as e:
            self._queue.put((MSG_ERROR, str(e)))

    def _poll_queue(self):
        """主线程轮询 queue，每 50ms 一次"""
        try:
            while True:
                msg_type, data = self._queue.get_nowait()
                try:
                    if msg_type == MSG_PROGRESS:
                        self.on_progress(data)
                    elif msg_type == MSG_LOG:
                        self.on_log(data)
                    elif msg_type == MSG_DONE:
                        self._running = False
                        self.on_complete(data)
                        return
                    elif msg_type == MSG_ERROR:
                        self._running = False
                        self.on_error(data)
                        return
                except Exception:
                    # 回调异常不应中断消息轮询
                    pass
        except queue.Empty:
            pass
        if self._running:
            self.root.after(50, self._poll_queue)
