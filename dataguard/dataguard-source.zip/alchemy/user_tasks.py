"""Pure filesystem helpers used by the simplified annotator workstation."""

from __future__ import annotations

from pathlib import Path


def safe_relative_child(base: Path, selected: Path) -> Path:
    base = base.resolve()
    selected = selected.resolve()
    try:
        relative = selected.relative_to(base)
    except ValueError as exc:
        raise ValueError("只能选择本人待办目录中的任务文件夹。") from exc
    if not relative.parts:
        raise ValueError("请选择具体任务文件夹，不能选择待办根目录。")
    return relative


def count_task_folders(root: Path) -> int:
    if not root.is_dir():
        return 0
    count = 0
    for item in root.rglob("*"):
        if not item.is_dir():
            continue
        try:
            if any(child.is_file() for child in item.iterdir()):
                count += 1
        except OSError:
            continue
    return count
