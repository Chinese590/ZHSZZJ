# alchemy/app.py
# AlchemyApp - 前端 UI 层

import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext, simpledialog
import ttkbootstrap as ttk
from ttkbootstrap.constants import *
from ttkbootstrap.style import Colors, ThemeDefinition
import os
import json
import subprocess
import platform
import random

from alchemy.constants import (
    UI_THEME, UI_GEOMETRY, UI_FONT_MONO, UI_FONT_CJK,
    UI_BG, UI_SURFACE, UI_PRIMARY, UI_ACCENT, UI_BORDER,
    UI_TEXT, UI_MUTED, UI_LIST_SELECTION,
    CONFIG_FILENAME, APP_TITLE, QC_NEW, QC_REWORK,
)
from alchemy.backend import AlchemyBackend
from alchemy.worker import TaskWorker
from alchemy.qc_launcher import ensure_qc_root, find_qc_launcher, launch_qc


class AlchemyApp:
    def __init__(self, root):
        self.root = root
        self.root.title(APP_TITLE)
        self.root.geometry(UI_GEOMETRY)
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)
        self.style = ttk.Style(theme=UI_THEME)
        self._configure_enterprise_theme()
        self.backend = AlchemyBackend()
        self.backend.log_callback = self.append_log
        self.worker = TaskWorker(
            self.root,
            on_progress=self._on_task_progress,
            on_log=self._on_task_log,
            on_complete=self._on_task_complete,
            on_error=self._on_task_error,
        )
        self.setup_ui()
        self.root.after(200, self.load_config)

    def _configure_enterprise_theme(self):
        """统一配置浅色企业蓝视觉，不改变控件行为。"""
        theme = ThemeDefinition(
            name="dataguard_enterprise",
            themetype="light",
            colors=Colors(
                primary=UI_PRIMARY,
                secondary=UI_MUTED,
                success="#2E7D32",
                info=UI_ACCENT,
                warning="#F59E0B",
                danger="#D64545",
                light=UI_SURFACE,
                dark=UI_TEXT,
                bg=UI_BG,
                fg=UI_TEXT,
                selectbg=UI_LIST_SELECTION,
                selectfg=UI_TEXT,
                border=UI_BORDER,
                inputfg=UI_TEXT,
                inputbg=UI_SURFACE,
                active="#EAF2FB",
            ),
        )
        self.style.register_theme(theme)
        self.style.theme_use(theme.name)
        self.root.configure(background=UI_BG)
        self.style.configure("TFrame", background=UI_SURFACE)
        self.style.configure("TLabel", background=UI_SURFACE, foreground=UI_TEXT, font=UI_FONT_CJK)
        self.style.configure("TLabelframe", background=UI_SURFACE, bordercolor=UI_BORDER, relief="solid")
        self.style.configure("TLabelframe.Label", background=UI_SURFACE, foreground=UI_PRIMARY, font=("Microsoft YaHei", 10, "bold"))
        self.style.configure("TNotebook", background=UI_BG, borderwidth=0)
        self.style.configure("TNotebook.Tab", padding=(16, 8), font=("Microsoft YaHei", 10))
        self.style.map("TNotebook.Tab", background=[("selected", UI_SURFACE)], foreground=[("selected", UI_PRIMARY)])
        self.style.configure("Treeview", background=UI_SURFACE, fieldbackground=UI_SURFACE, foreground=UI_TEXT, rowheight=28, bordercolor=UI_BORDER)
        self.style.configure("Treeview.Heading", background=UI_PRIMARY, foreground="white", font=("Microsoft YaHei", 10, "bold"), relief="flat")
        self.style.map("Treeview", background=[("selected", UI_LIST_SELECTION)], foreground=[("selected", UI_TEXT)])

    def on_close(self):
        if self.worker.is_running():
            if not messagebox.askyesno("确认", "正在处理素材，确定关闭？\n（程序会等待当前文件操作完成后再关闭）"):
                return
            self.worker.cancel()
            self._force_close_attempts = 0
            self.root.after(500, self._force_close)
            return
        self.save_config()
        self.backend.close()
        self.root.destroy()

    def _force_close(self):
        """强制关闭（后台线程取消后）"""
        self._force_close_attempts += 1
        if self.worker.is_running() and self._force_close_attempts < 10:
            # 后台线程仍在运行，再等一会儿让它安全退出（最多等 5 秒）
            self.root.after(500, self._force_close)
            return
        self.save_config()
        self.backend.close()
        self.root.destroy()

    def save_config(self):
        config = {
            "root_path": self.backend.project_root,
            "last_category": self.var_category.get() if hasattr(self, 'var_category') else "",
            "last_batch": self.combo_batches.get() if hasattr(self, 'combo_batches') else "",
            "last_group": self.var_group_filter.get() if hasattr(self, 'var_group_filter') else "全部",
            "last_recovery_level1": self.var_recovery_level1.get() if hasattr(self, 'var_recovery_level1') else "",
            "last_recovery_level2": self.var_recovery_level2.get() if hasattr(self, 'var_recovery_level2') else "",
            "hide_empty_batches": self.var_hide_empty_batches.get() if hasattr(self, 'var_hide_empty_batches') else True,
            "last_harvest_user": self.combo_harvest_user.get() if hasattr(self, 'combo_harvest_user') else "",
            "harvest_collect_unfinished": self.var_harvest_collect_unfinished.get() if hasattr(self, 'var_harvest_collect_unfinished') else False,
            "qa_mode": self.var_qa_mode.get() if hasattr(self, 'var_qa_mode') else "new",
            "last_qa_target": self.combo_target_qa.get() if hasattr(self, 'combo_target_qa') else "",
            "qc_root_path": self.var_qa_root.get() if hasattr(self, "var_qa_root") else ""
        }
        try:
            with open(CONFIG_FILENAME, "w", encoding='utf-8') as f:
                json.dump(config, f, indent=4, ensure_ascii=False)
        except (OSError, TypeError, ValueError):
            pass

    def load_config(self):
        if not os.path.exists(CONFIG_FILENAME):
            return
        try:
            with open(CONFIG_FILENAME, "r", encoding='utf-8') as f:
                data = json.load(f)
        except (OSError, json.JSONDecodeError) as e:
            self.append_log(f"⚠️ 读取记忆失败: {e}")
            return

        path = data.get("root_path", "")
        if not isinstance(path, str) or not path or not os.path.exists(path):
            return

        self.backend.set_root(path)
        self.on_connect_success(path)
        saved_qc_root = data.get("qc_root_path", "")
        if hasattr(self, "var_qa_root") and isinstance(saved_qc_root, str) and saved_qc_root.strip():
            self.var_qa_root.set(saved_qc_root)

        saved_level1 = data.get("last_recovery_level1", "")
        saved_level2 = data.get("last_recovery_level2", "")
        if saved_level1 in self.combo_recovery_level1["values"]:
            self.var_recovery_level1.set(saved_level1)
            self.on_recovery_level1_changed()
            if saved_level2 in self.combo_recovery_level2["values"]:
                self.var_recovery_level2.set(saved_level2)

        try:
            val = data.get("hide_empty_batches", True)
            if isinstance(val, bool):
                self.var_hide_empty_batches.set(val)
        except Exception:
            pass

        try:
            saved_cat = data.get("last_category", "")
            if isinstance(saved_cat, str) and saved_cat:
                cats = self.backend.get_raw_categories()
                if saved_cat in cats:
                    self.var_category.set(saved_cat)
                    self.on_category_btn_click()
                    saved_batch = data.get("last_batch", "")
                    if isinstance(saved_batch, str) and saved_batch in self.combo_batches['values']:
                        self.combo_batches.set(saved_batch)
                        self.on_batch_selected(None)
                        # 恢复分组选择
                        saved_group = data.get("last_group", "全部")
                        if isinstance(saved_group, str) and saved_group:
                            # 检查该分组按钮是否存在
                            group_values = [w.cget("value") for w in self.frame_group_buttons.winfo_children() if hasattr(w, 'cget')]
                            if saved_group in group_values:
                                self.var_group_filter.set(saved_group)
                                self.on_group_filter_click()
        except Exception:
            pass

        try:
            user = data.get("last_harvest_user", "")
            if isinstance(user, str) and user in self.combo_harvest_user['values']:
                self.combo_harvest_user.set(user)
        except Exception:
            pass

        try:
            val = data.get("harvest_collect_unfinished", False)
            if isinstance(val, bool):
                self.var_harvest_collect_unfinished.set(val)
        except Exception:
            pass

        try:
            mode = data.get("qa_mode", "new")
            if isinstance(mode, str) and mode in ("new", "rework"):
                self.var_qa_mode.set(mode)
                self.on_qa_mode_change()
        except Exception:
            pass

        try:
            target = data.get("last_qa_target", "")
            if isinstance(target, str) and target in self.combo_target_qa['values']:
                self.combo_target_qa.set(target)
        except Exception:
            pass

        self.append_log("✨ 系统记忆已恢复")

    def setup_ui(self):
        frame_top = ttk.Labelframe(self.root, text="系统连接", padding=10)
        frame_top.pack(fill="x", padx=10, pady=5)
        self.lbl_path = ttk.Label(frame_top, text="⚠️ 传送阵未连接", bootstyle="danger")
        self.lbl_path.pack(side="left", fill="x", expand=True)
        btn_browse = ttk.Button(frame_top, text="📂 挂载路径", bootstyle="info-outline", command=self.browse_folder)
        btn_browse.pack(side="right")
        self.btn_init_dirs = ttk.Button(frame_top, text="📁 创建目录", bootstyle="primary-outline", command=self.on_init_directories, state="disabled")
        self.btn_init_dirs.pack(side="right", padx=5)
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill="both", expand=True, padx=10, pady=5)
        self.setup_tab_distribute()
        self.setup_tab_harvest()
        self.setup_tab_history()
        self.setup_tab_qa_distribute()
        self.setup_tab_logs()
        frame_log = ttk.Labelframe(self.root, text="运行日志", padding=5)
        frame_log.pack(fill="both", expand=True, padx=10, pady=5)
        self.txt_log = scrolledtext.ScrolledText(frame_log, height=6, state="disabled", font=UI_FONT_MONO, bg=UI_SURFACE, fg=UI_TEXT, insertbackground=UI_TEXT, selectbackground=UI_LIST_SELECTION, relief="solid", borderwidth=1)
        self.txt_log.pack(fill="both", expand=True)

        frame_progress = ttk.Frame(self.root)
        frame_progress.pack(fill="x", padx=10, pady=(0, 5))
        self.progress_var = tk.DoubleVar()
        self.progress_bar = ttk.Progressbar(frame_progress, variable=self.progress_var, maximum=100, bootstyle="primary")
        self.progress_bar.pack(side="left", fill="x", expand=True)
        self.lbl_progress = ttk.Label(frame_progress, text="", bootstyle="secondary")
        self.lbl_progress.pack(side="left", padx=10)

        self.enable_controls(False)

    def setup_tab_distribute(self):
        self.tab_dist = ttk.Frame(self.notebook, padding=10)
        self.notebook.add(self.tab_dist, text="💎 素材分发")
        frame_left = ttk.Labelframe(self.tab_dist, text="库存池", padding=10)
        frame_left.pack(side="left", fill="both", expand=True)
        frame_cat = ttk.Frame(frame_left)
        frame_cat.pack(fill="x", pady=2)
        ttk.Label(frame_cat, text="类别:", width=6).pack(side="left", anchor="n", pady=5)
        self.var_hide_empty_batches = tk.BooleanVar(value=True)
        ttk.Checkbutton(frame_cat, text="隐藏空批次", variable=self.var_hide_empty_batches, bootstyle="round-toggle", command=self.on_category_btn_click).pack(side="right", padx=5)
        self.frame_cat_buttons = ttk.Frame(frame_cat)
        self.frame_cat_buttons.pack(side="left", fill="x", expand=True)
        self.var_category = tk.StringVar()
        frame_batch = ttk.Frame(frame_left)
        frame_batch.pack(fill="x", pady=(10, 2))
        ttk.Label(frame_batch, text="批次:", width=6).pack(side="left")
        self.combo_batches = ttk.Combobox(frame_batch, state="readonly")
        self.combo_batches.pack(side="left", fill="x", expand=True, padx=5)
        self.combo_batches.bind("<<ComboboxSelected>>", self.on_batch_selected)
        # --- 分组筛选栏 ---
        frame_group = ttk.Frame(frame_left)
        frame_group.pack(fill="x", pady=(10, 2))
        ttk.Label(frame_group, text="分组:", width=6).pack(side="left")
        self.frame_group_buttons = ttk.Frame(frame_group)
        self.frame_group_buttons.pack(side="left", fill="x", expand=True)
        self.var_group_filter = tk.StringVar(value="全部")
        self.var_random_shuffle = tk.BooleanVar(value=False)
        self._item_display_data = []  # [(显示文本, 分组名, 类型), ...]
        # 分组管理按钮
        frame_group_mgmt = ttk.Frame(frame_left)
        frame_group_mgmt.pack(fill="x", pady=(0, 2))
        ttk.Button(frame_group_mgmt, text="➕新建", bootstyle="success-outline", command=self.on_create_group_click, width=8).pack(side="left", padx=2)
        self.btn_rename_group = ttk.Button(frame_group_mgmt, text="✏️重命名", bootstyle="warning-outline", command=self.on_rename_group_click, width=8, state="disabled")
        self.btn_rename_group.pack(side="left", padx=2)
        self.btn_delete_group = ttk.Button(frame_group_mgmt, text="🗑️删除", bootstyle="danger-outline", command=self.on_delete_group_click, width=8, state="disabled")
        self.btn_delete_group.pack(side="left", padx=2)
        frame_list = ttk.Frame(frame_left)
        frame_list.pack(fill="both", expand=True, pady=5)
        self.list_raw = tk.Listbox(frame_list, selectmode=tk.EXTENDED, font=UI_FONT_MONO, exportselection=False, bg=UI_SURFACE, fg=UI_TEXT, selectbackground=UI_LIST_SELECTION, selectforeground=UI_TEXT, relief="solid", borderwidth=1, highlightcolor=UI_ACCENT)
        scroll_y = ttk.Scrollbar(frame_list, orient="vertical", command=self.list_raw.yview)
        self.list_raw.configure(yscrollcommand=scroll_y.set)
        self.list_raw.pack(side="left", fill="both", expand=True)
        scroll_y.pack(side="right", fill="y")
        frame_raw_tools = ttk.Frame(frame_left)
        frame_raw_tools.pack(fill="x", pady=5)
        self.lbl_select_info = ttk.Label(frame_raw_tools, text="已选: 0", bootstyle="info")
        self.lbl_select_info.pack(side="left")
        ttk.Button(frame_raw_tools, text="全选", bootstyle="secondary-outline", command=self.select_all, width=6).pack(side="right", padx=2)
        ttk.Button(frame_raw_tools, text="前50", bootstyle="secondary-outline", command=lambda: self.select_quick(50), width=6).pack(side="right", padx=2)
        # 数量快速选中
        ttk.Button(frame_raw_tools, text="选中", bootstyle="info-outline", command=self.select_by_spinbox, width=4).pack(side="right", padx=(0, 0))
        self.spin_select_count = ttk.Spinbox(frame_raw_tools, from_=1, to=9999, width=5, bootstyle="info")
        self.spin_select_count.set(10)
        self.spin_select_count.pack(side="right", padx=(2, 2))
        self.list_raw.bind("<<ListboxSelect>>", self.on_list_select)
        frame_right = ttk.Labelframe(self.tab_dist, text="目标人员", padding=10)
        frame_right.pack(side="right", fill="both", expand=True, padx=(10, 0))
        frame_users_list = ttk.Frame(frame_right)
        frame_users_list.pack(fill="both", expand=True)
        self.list_users_dist = tk.Listbox(frame_users_list, selectmode=tk.EXTENDED, height=15, font=UI_FONT_CJK, exportselection=False, bg=UI_SURFACE, fg=UI_TEXT, selectbackground=UI_LIST_SELECTION, selectforeground=UI_TEXT, relief="solid", borderwidth=1, highlightcolor=UI_ACCENT)
        scroll_u = ttk.Scrollbar(frame_users_list, orient="vertical", command=self.list_users_dist.yview)
        self.list_users_dist.configure(yscrollcommand=scroll_u.set)
        self.list_users_dist.pack(side="left", fill="both", expand=True)
        scroll_u.pack(side="right", fill="y")
        self.list_users_dist.bind("<Double-Button-1>", self.on_user_double_click)
        ttk.Button(frame_right, text="🔄 刷新名单", bootstyle="info-outline", command=self.on_refresh_click).pack(fill="x", pady=5)
        ttk.Button(frame_right, text="➕ 新建用户", bootstyle="success-outline", command=self.on_create_user_click).pack(fill="x", pady=2)
        frame_actions = ttk.Labelframe(frame_right, text="执行", padding=10)
        frame_actions.pack(fill="x", pady=10)
        ttk.Label(frame_actions, text="下发类目（最多两级）").pack(anchor="w")
        frame_recovery_cat = ttk.Frame(frame_actions)
        frame_recovery_cat.pack(fill="x", pady=(2, 5))
        self.var_recovery_level1 = tk.StringVar()
        self.var_recovery_level2 = tk.StringVar()
        self.combo_recovery_level1 = ttk.Combobox(frame_recovery_cat, textvariable=self.var_recovery_level1, state="readonly", width=10)
        self.combo_recovery_level1.pack(side="left", fill="x", expand=True)
        self.combo_recovery_level1.bind("<<ComboboxSelected>>", self.on_recovery_level1_changed)
        self.combo_recovery_level2 = ttk.Combobox(frame_recovery_cat, textvariable=self.var_recovery_level2, state="readonly", width=10)
        self.combo_recovery_level2.pack(side="left", fill="x", expand=True, padx=(4, 0))
        frame_recovery_tools = ttk.Frame(frame_actions)
        frame_recovery_tools.pack(fill="x", pady=(0, 4))
        ttk.Button(frame_recovery_tools, text="➕类目", command=self.on_add_recovery_category, bootstyle="success-outline").pack(side="left", expand=True, fill="x")
        ttk.Button(frame_recovery_tools, text="✏️重命名", command=self.on_rename_recovery_category, bootstyle="warning-outline").pack(side="left", expand=True, fill="x", padx=3)
        ttk.Button(frame_recovery_tools, text="🗑️删除", command=self.on_delete_recovery_category, bootstyle="danger-outline").pack(side="left", expand=True, fill="x")
        ttk.Checkbutton(frame_actions, text="🔀 随机打乱发送", variable=self.var_random_shuffle, bootstyle="round-toggle").pack(fill="x", pady=2)
        self.btn_dist_split = ttk.Button(frame_actions, text="⚖️ 均分发送", bootstyle="primary", command=self.on_distribute_split)
        self.btn_dist_split.pack(fill="x", pady=5, ipady=5)
        self.lbl_global_stock = ttk.Label(frame_right, text="🌍 世界总库存: -", bootstyle="secondary")
        self.lbl_global_stock.pack(side="bottom", pady=2)
        self.lbl_category_stock = ttk.Label(frame_right, text="📚 分类库存: -", bootstyle="primary")
        self.lbl_category_stock.pack(side="bottom", pady=2)
        self.lbl_reserve_count = ttk.Label(frame_right, text="🍞 批次库存: 0", bootstyle="warning")
        self.lbl_reserve_count.pack(side="bottom", pady=2)

    def setup_tab_harvest(self):
        self.tab_harvest = ttk.Frame(self.notebook, padding=10)
        self.notebook.add(self.tab_harvest, text="📥 产物回收")
        frame_monitor = ttk.Labelframe(self.tab_harvest, text="产出监控 (实时)", padding=10)
        frame_monitor.pack(fill="both", expand=True)
        columns = ("user", "dist", "normal", "rework", "abandoned", "pending", "total")
        self.tree_status = ttk.Treeview(frame_monitor, columns=columns, show="headings", height=8, bootstyle="info")
        self.tree_status.heading("user", text="炼金师")
        self.tree_status.heading("dist", text="📦 今日领料")
        self.tree_status.heading("normal", text="✅ 成品")
        self.tree_status.heading("rework", text="🔧 返修")
        self.tree_status.heading("abandoned", text="🗑️ 废料")
        self.tree_status.heading("pending", text="⏳ 积压")
        self.tree_status.heading("total", text="∑ 今日产出")
        self.tree_status.column("user", width=120, anchor="center")
        self.tree_status.column("dist", width=80, anchor="center")
        for col in ["normal", "rework", "abandoned", "pending", "total"]:
            self.tree_status.column(col, width=80, anchor="center")
        self.tree_status.pack(side="left", fill="both", expand=True)
        scroll = ttk.Scrollbar(frame_monitor, orient="vertical", command=self.tree_status.yview)
        scroll.pack(side="right", fill="y")
        self.tree_status.configure(yscrollcommand=scroll.set)
        ttk.Button(frame_monitor, text="🔄 刷新数据", width=10, bootstyle="info-outline", command=self.refresh_harvest_status).pack(side="bottom", fill="x", pady=5)
        frame_action = ttk.Labelframe(self.tab_harvest, text="回收操作", padding=10)
        frame_action.pack(fill="x", pady=10)
        self.var_separate_psd = tk.BooleanVar(value=True)
        ttk.Checkbutton(frame_action, text="回收时分离PSD文件至PSD备份库", variable=self.var_separate_psd, bootstyle="round-toggle").pack(anchor="w", padx=10, pady=(0, 6))
        self.var_harvest_collect_unfinished = tk.BooleanVar(value=False)
        ttk.Checkbutton(frame_action, text="回收时强制回收 To_Do", variable=self.var_harvest_collect_unfinished, bootstyle="round-toggle").pack(anchor="w", padx=10, pady=(0, 10))
        frame_btns = ttk.Frame(frame_action)
        frame_btns.pack(fill="x")
        self.btn_harvest_all = ttk.Button(frame_btns, text="🌍 全员回收", bootstyle="warning", command=self.on_harvest_all)
        self.btn_harvest_all.pack(side="left", fill="x", expand=True, padx=5)
        frame_r = ttk.Frame(frame_btns)
        frame_r.pack(side="right", fill="x", expand=True)
        self.combo_harvest_user = ttk.Combobox(frame_r, state="readonly", width=15)
        self.combo_harvest_user.pack(side="left", padx=5)
        self.btn_harvest_single = ttk.Button(frame_r, text="🎯 单人回收", bootstyle="secondary", command=self.on_harvest_single)
        self.btn_harvest_single.pack(side="left", padx=5)

    def setup_tab_history(self):
        self.tab_history = ttk.Frame(self.notebook, padding=10)
        self.notebook.add(self.tab_history, text="📅 时回")
        frame_selector = ttk.Frame(self.tab_history)
        frame_selector.pack(fill="x", pady=5)
        ttk.Label(frame_selector, text="日期:").pack(side="left")
        self.combo_dates = ttk.Combobox(frame_selector, state="readonly", width=20)
        self.combo_dates.pack(side="left", padx=10)
        self.combo_dates.bind("<<ComboboxSelected>>", self.on_date_selected)
        ttk.Button(frame_selector, text="🔄", width=4, bootstyle="outline", command=self.refresh_dates).pack(side="left")
        ttk.Button(frame_selector, text="📂 新标", bootstyle="success-outline", command=lambda: self.open_qc_folder(QC_NEW)).pack(side="right", padx=2)
        ttk.Button(frame_selector, text="📂 返修", bootstyle="primary-outline", command=lambda: self.open_qc_folder(QC_REWORK)).pack(side="right", padx=2)
        frame_board = ttk.Labelframe(self.tab_history, text="数据概览", padding=15)
        frame_board.pack(fill="x", pady=10)
        self.lbl_hist_normal = ttk.Label(frame_board, text="✅ 新标: -", bootstyle="success")
        self.lbl_hist_normal.pack(side="left", expand=True)
        self.lbl_hist_rework = ttk.Label(frame_board, text="🔧 返修: -", bootstyle="primary")
        self.lbl_hist_rework.pack(side="left", expand=True)
        self.lbl_hist_abandon = ttk.Label(frame_board, text="🗑️ 废料: -", bootstyle="danger")
        self.lbl_hist_abandon.pack(side="left", expand=True)
        self.lbl_hist_total = ttk.Label(frame_board, text="合计: -", bootstyle="inverse-light")
        self.lbl_hist_total.pack(side="left", expand=True)
        frame_detail = ttk.Frame(self.tab_history, padding=10)
        frame_detail.pack(fill="both", expand=True)
        columns = ("user", "new", "rework", "total")
        self.tree_history = ttk.Treeview(frame_detail, columns=columns, show="headings", bootstyle="primary")
        for col in columns:
            self.tree_history.heading(col, text=col, anchor="center")
            self.tree_history.column(col, anchor="center")
        self.tree_history.pack(fill="both", expand=True)

    def setup_tab_qa_distribute(self):
        self.tab_qa = ttk.Frame(self.notebook, padding=20)
        self.notebook.add(self.tab_qa, text="📤 样本")
        frame_l = ttk.Labelframe(self.tab_qa, text="1. 源", padding=15)
        frame_l.pack(side="left", fill="both", expand=True, padx=(0, 10))
        frame_line1 = ttk.Frame(frame_l)
        frame_line1.pack(fill="x", pady=5)
        ttk.Label(frame_line1, text="日期:").pack(side="left")
        self.combo_qa_date = ttk.Combobox(frame_line1, state="readonly", width=15)
        self.combo_qa_date.pack(side="left", padx=10)
        self.combo_qa_date.bind("<<ComboboxSelected>>", self.on_qa_date_select)
        frame_line2 = ttk.Frame(frame_l)
        frame_line2.pack(fill="x", pady=5)
        self.var_qa_mode = tk.StringVar(value="new")
        ttk.Radiobutton(frame_line2, text="新标", variable=self.var_qa_mode, value="new", command=self.on_qa_mode_change).pack(side="left", padx=10)
        ttk.Radiobutton(frame_line2, text="返修", variable=self.var_qa_mode, value="rework", command=self.on_qa_mode_change).pack(side="left", padx=10)
        self.list_qa_users = tk.Listbox(frame_l, selectmode=tk.EXTENDED, height=15, font=UI_FONT_MONO, bg=UI_SURFACE, fg=UI_TEXT, selectbackground=UI_LIST_SELECTION, selectforeground=UI_TEXT, relief="solid", borderwidth=1, highlightcolor=UI_ACCENT)
        self.list_qa_users.pack(fill="both", expand=True)
        self.list_qa_users.bind("<<ListboxSelect>>", self.on_qa_user_select_change)
        frame_r = ttk.Labelframe(self.tab_qa, text="2. 验收员", padding=15)
        frame_r.pack(side="right", fill="both", expand=True)
        self.combo_target_qa = ttk.Combobox(frame_r, state="readonly")
        self.combo_target_qa.pack(fill="x", pady=5)
        self.lbl_qa_info = ttk.Label(frame_r, text="等待...")
        self.lbl_qa_info.pack(pady=10)

        qc_root_frame = ttk.Labelframe(frame_r, text="管理员直接质检", padding=10)
        qc_root_frame.pack(fill="x", pady=(8, 12))
        self.var_qa_root = tk.StringVar()
        ttk.Entry(qc_root_frame, textvariable=self.var_qa_root, state="readonly").pack(fill="x", pady=(0, 8))
        qc_btn_row = ttk.Frame(qc_root_frame)
        qc_btn_row.pack(fill="x")
        ttk.Button(qc_btn_row, text="选择质检目录", bootstyle="secondary-outline", command=self.on_choose_qa_root).pack(side="left", fill="x", expand=True, padx=(0, 5))
        self.btn_start_qc = ttk.Button(qc_btn_row, text="▶ 直接开始质检", bootstyle="success", command=self.on_start_qc)
        self.btn_start_qc.pack(side="right", fill="x", expand=True, padx=(5, 0))

        self.btn_qa_send = ttk.Button(frame_r, text="🚀 下发", bootstyle="primary", command=self.on_qa_distribute)
        self.btn_qa_send.pack(side="bottom", fill="x", ipady=15)

    def setup_tab_logs(self):
        self.tab_logs = ttk.Frame(self.notebook, padding=10)
        self.notebook.add(self.tab_logs, text="📜 日志")
        frame_tool = ttk.Frame(self.tab_logs)
        frame_tool.pack(fill="x", pady=5)
        ttk.Button(frame_tool, text="🔄 刷新", command=self.refresh_log_list).pack(side="left")
        self.tree_logs = ttk.Treeview(self.tab_logs, columns=("date", "filename", "size"), show="headings", height=15)
        for col in ("date", "filename", "size"):
            self.tree_logs.heading(col, text=col)
            self.tree_logs.column(col, anchor="w")
        self.tree_logs.pack(fill="both", expand=True)
        self.tree_logs.bind("<Double-1>", self.on_log_double_click)
        self.btn_open_log = ttk.Button(self.tab_logs, text="🚀 打开表格", bootstyle="primary", command=self.on_open_log_click)
        self.btn_open_log.pack(fill="x", pady=10)

    # --- Interaction Logic ---
    def on_connect_success(self, path):
        self.lbl_path.config(text=path, bootstyle="success")
        self.enable_controls(True)
        self.btn_init_dirs.config(state="normal")
        self.refresh_categories_and_batches()
        self.refresh_users()
        self.refresh_harvest_status()
        self.refresh_dates()
        self.refresh_qa_targets()
        self.refresh_log_list()
        self.refresh_recovery_categories()
        if hasattr(self, "var_qa_root") and not self.var_qa_root.get().strip():
            self.var_qa_root.set(os.path.join(path, "04_Quality_Check", "质检工作台"))

    def append_log(self, msg):
        self.txt_log.config(state="normal")
        self.txt_log.insert("end", f"> {msg}\n")
        self.txt_log.see("end")
        self.txt_log.config(state="disabled")

    def refresh_recovery_categories(self):
        categories = self.backend.get_recovery_categories() if self.backend.project_root else {}
        levels = list(categories)
        self.combo_recovery_level1["values"] = levels
        if self.var_recovery_level1.get() not in levels:
            self.var_recovery_level1.set(levels[0] if levels else "")
        self.on_recovery_level1_changed()

    def on_recovery_level1_changed(self, event=None):
        categories = self.backend.get_recovery_categories() if self.backend.project_root else {}
        children = categories.get(self.var_recovery_level1.get(), [])
        self.combo_recovery_level2["values"] = [""] + children
        if self.var_recovery_level2.get() not in children:
            self.var_recovery_level2.set(children[0] if children else "")

    def on_add_recovery_category(self):
        if not self.backend.project_root:
            return messagebox.showwarning("提示", "请先连接项目目录")
        level1 = simpledialog.askstring("新增类目", "一级类目名称：", parent=self.root)
        if not level1:
            return
        level2 = simpledialog.askstring("新增类目", "二级类目名称（可留空）：", parent=self.root) or ""
        ok, msg = self.backend.add_recovery_category(level1, level2)
        if not ok:
            return messagebox.showerror("新增失败", msg)
        self.refresh_recovery_categories()
        self.var_recovery_level1.set(level1)
        self.on_recovery_level1_changed()
        self.var_recovery_level2.set(level2)

    def on_rename_recovery_category(self):
        level1 = self.var_recovery_level1.get()
        level2 = self.var_recovery_level2.get()
        if not level1:
            return messagebox.showwarning("提示", "请先选择类目")
        old_name = level2 or level1
        new_name = simpledialog.askstring("重命名类目", f"将“{old_name}”重命名为：", parent=self.root)
        if not new_name:
            return
        new_level1 = level1 if level2 else new_name
        new_level2 = new_name if level2 else ""
        ok, msg = self.backend.rename_recovery_category(level1, level2, new_level1, new_level2)
        if not ok:
            return messagebox.showerror("重命名失败", msg)
        self.refresh_recovery_categories()
        self.var_recovery_level1.set(new_level1)
        self.on_recovery_level1_changed()
        self.var_recovery_level2.set(new_level2)

    def on_delete_recovery_category(self):
        level1 = self.var_recovery_level1.get()
        level2 = self.var_recovery_level2.get()
        if not level1:
            return messagebox.showwarning("提示", "请先选择类目")
        label = f"{level1}/{level2}" if level2 else level1
        if not messagebox.askyesno("确认删除", f"删除类目“{label}”？\n非空类目不会被删除。"):
            return
        ok, msg = self.backend.delete_recovery_category(level1, level2)
        if not ok:
            return messagebox.showerror("删除失败", msg)
        self.refresh_recovery_categories()

    def _on_task_progress(self, data):
        """后台任务进度回调"""
        current, total = data
        self.update_progress(current, total)

    def _on_task_log(self, msg):
        """后台任务日志回调"""
        self.append_log(msg)

    def _on_task_complete(self, result):
        """后台任务完成回调"""
        self.clear_progress()
        self._set_buttons_enabled(True)
        if hasattr(self, '_pending_complete_handler'):
            self._pending_complete_handler(result)

    def _on_task_error(self, error_msg):
        """后台任务错误回调"""
        self.clear_progress()
        self._set_buttons_enabled(True)
        self.append_log(f"❌ 任务失败: {error_msg}")
        messagebox.showerror("错误", f"操作失败:\n{error_msg}")

    def _harvest_complete(self, result):
        """回收操作完成回调（全员/单人共用）"""
        n, r, a, c, name, skipped = result
        msg = f"✅新标: {n}\n🔧返修: {r}\n🗑️废弃: {a}\n🔙退回: {c}"
        if skipped > 0:
            msg += f"\n⚠️跳过: {skipped}"
        messagebox.showinfo("报告", msg)
        self.refresh_harvest_status()
        self.refresh_dates()

    def _set_buttons_enabled(self, enabled):
        """启用/禁用操作按钮"""
        st = "normal" if enabled else "disabled"
        if hasattr(self, 'btn_dist_split'):
            self.btn_dist_split.config(state=st)
        if hasattr(self, 'btn_harvest_all'):
            self.btn_harvest_all.config(state=st)
        if hasattr(self, 'btn_harvest_single'):
            self.btn_harvest_single.config(state=st)
        if hasattr(self, 'btn_qa_send'):
            self.btn_qa_send.config(state=st)
        if hasattr(self, 'btn_open_log'):
            self.btn_open_log.config(state=st)
        if hasattr(self, 'btn_delete_group'):
            self.btn_delete_group.config(state=st)

    def update_progress(self, current, total):
        if total > 0:
            percentage = (current / total) * 100
            self.progress_var.set(percentage)
            self.lbl_progress.config(text=f"处理中: {current}/{total}")

    def clear_progress(self):
        self.progress_var.set(0)
        self.lbl_progress.config(text="")

    def enable_controls(self, enable):
        st = "normal" if enable else "disabled"
        self.combo_batches.config(state=st)
        self.combo_harvest_user.config(state=st)
        self.combo_dates.config(state=st)
        self.combo_qa_date.config(state=st)
        self.list_qa_users.config(state=st)
        if hasattr(self, 'list_users_dist'):
            self.list_users_dist.config(state=st)
        self._set_buttons_enabled(enable)

    def browse_folder(self):
        path = filedialog.askdirectory()
        if path:
            success, msg = self.backend.set_root(path)
            if success:
                self.on_connect_success(path)
                self.save_config()
            else:
                self.lbl_path.config(text=msg, bootstyle="danger")
                self.enable_controls(False)

    def on_init_directories(self):
        self.append_log("🔧 正在创建目录...")
        success, msg = self.backend.init_directories()
        if success:
            self.append_log(msg)
            messagebox.showinfo("完成", msg)
        else:
            self.append_log(f"❌ 创建失败: {msg}")
            messagebox.showerror("错误", msg)

    def on_create_user_click(self):
        username = simpledialog.askstring("新建用户", "请输入用户名:", parent=self.root)
        if username:
            success, msg = self.backend.create_user_folders(username)
            if success:
                messagebox.showinfo("完成", msg)
                self.append_log(msg)
                self.refresh_users()
            else:
                messagebox.showerror("错误", msg)

    def on_create_group_click(self):
        """新建分组弹窗"""
        cat = self.var_category.get()
        batch = self.combo_batches.get()
        if not cat or not batch:
            return messagebox.showwarning("提示", "请先选择类别和批次")
        # 弹窗：输入分组名 + 选择类型
        dlg = ttk.Toplevel(self.root)
        dlg.title("新建分组")
        dlg.geometry("350x250")
        dlg.resizable(False, False)
        dlg.grab_set()
        ttk.Label(dlg, text="分组名称:").pack(anchor="w", padx=20, pady=(15, 2))
        entry_name = ttk.Entry(dlg)
        entry_name.pack(fill="x", padx=20)
        ttk.Label(dlg, text="(自动加【】包裹，仅允许中文/英文/数字/下划线)").pack(anchor="w", padx=20)
        ttk.Label(dlg, text="分组类型:").pack(anchor="w", padx=20, pady=(15, 2))
        var_type = tk.StringVar(value="folder")
        ttk.Radiobutton(dlg, text="文件夹组 —— 放八位数文件夹", variable=var_type, value="folder").pack(anchor="w", padx=30)
        ttk.Radiobutton(dlg, text="图片组   —— 放散落图片", variable=var_type, value="image").pack(anchor="w", padx=30)
        result = {"done": False}
        def on_ok():
            name = entry_name.get().strip()
            if not name:
                messagebox.showwarning("提示", "请输入分组名", parent=dlg)
                return
            ok, msg, gname = self.backend.create_group(cat, batch, name, var_type.get())
            if ok:
                messagebox.showinfo("完成", msg, parent=dlg)
                self.append_log(msg)
                self.refresh_groups()
                self.refresh_group_items()
                result["done"] = True
                dlg.destroy()
            else:
                messagebox.showerror("错误", msg, parent=dlg)
        btn_frame = ttk.Frame(dlg)
        btn_frame.pack(side="bottom", fill="x", padx=20, pady=15)
        ttk.Button(btn_frame, text="确定", bootstyle="success", command=on_ok).pack(side="left", expand=True, fill="x", padx=5)
        ttk.Button(btn_frame, text="取消", command=dlg.destroy).pack(side="right", expand=True, fill="x", padx=5)

    def on_rename_group_click(self):
        """重命名分组弹窗"""
        cat = self.var_category.get()
        batch = self.combo_batches.get()
        gf = self.var_group_filter.get()
        if not cat or not batch:
            return messagebox.showwarning("提示", "请先选择类别和批次")
        if gf in ("全部", "__ungrouped__"):
            return messagebox.showwarning("提示", "请先选中一个分组再重命名")
        # gf 就是当前分组名，如 "【项目A】"
        dlg = ttk.Toplevel(self.root)
        dlg.title("重命名分组")
        dlg.geometry("350x200")
        dlg.resizable(False, False)
        dlg.grab_set()
        ttk.Label(dlg, text=f"当前名称: {gf}").pack(anchor="w", padx=20, pady=(15, 2))
        ttk.Label(dlg, text="新名称:").pack(anchor="w", padx=20, pady=(10, 2))
        entry_name = ttk.Entry(dlg)
        entry_name.pack(fill="x", padx=20)
        ttk.Label(dlg, text="(仅允许中文/英文/数字/下划线)").pack(anchor="w", padx=20)
        def on_ok():
            new_name = entry_name.get().strip()
            if not new_name:
                messagebox.showwarning("提示", "请输入新名称", parent=dlg)
                return
            ok, msg = self.backend.rename_group(cat, batch, gf, new_name)
            if ok:
                messagebox.showinfo("完成", msg, parent=dlg)
                self.append_log(msg)
                self.var_group_filter.set(f"【{new_name}】")
                self.refresh_groups()
                self.refresh_group_items()
                dlg.destroy()
            else:
                messagebox.showerror("错误", msg, parent=dlg)
        btn_frame = ttk.Frame(dlg)
        btn_frame.pack(side="bottom", fill="x", padx=20, pady=15)
        ttk.Button(btn_frame, text="确定", bootstyle="success", command=on_ok).pack(side="left", expand=True, fill="x", padx=5)
        ttk.Button(btn_frame, text="取消", command=dlg.destroy).pack(side="right", expand=True, fill="x", padx=5)

    def on_delete_group_click(self):
        """删除分组"""
        cat = self.var_category.get()
        batch = self.combo_batches.get()
        gf = self.var_group_filter.get()
        if not cat or not batch:
            return messagebox.showwarning("提示", "请先选择类别和批次")
        if gf in ("全部", "__ungrouped__"):
            return messagebox.showwarning("提示", "请先选中一个分组再删除")
        if not messagebox.askyesno("确认删除", f"确定删除分组 {gf} ？\n组内素材将退回批次根目录。"):
            return
        ok, msg = self.backend.delete_group(cat, batch, gf)
        if ok:
            self.append_log(msg)
            self.var_group_filter.set("全部")
            self.refresh_groups()
            self.refresh_group_items()
        else:
            messagebox.showerror("错误", msg)

    def refresh_categories_and_batches(self):
        for w in self.frame_cat_buttons.winfo_children():
            w.destroy()
        cats = self.backend.get_raw_categories()
        self.lbl_global_stock.config(text=f"🌍 世界总库存: {self.backend.get_total_raw_count()}")
        if not cats:
            return
        for cat in cats:
            ttk.Radiobutton(self.frame_cat_buttons, text=cat, variable=self.var_category, value=cat, bootstyle="info-toolbutton", command=self.on_category_btn_click).pack(side="left", padx=2)
        self.var_category.set(cats[0])
        self.on_category_btn_click()

    def on_refresh_click(self):
        self.refresh_users()
        self.refresh_categories_and_batches()

    def on_user_double_click(self, event):
        selection = self.list_users_dist.curselection()
        if selection:
            user = self.list_users_dist.get(selection[0])
            user_path = self.backend.get_user_path(user)
            if os.path.exists(user_path):
                self.open_folder(user_path)
                self.append_log(f"📂 已打开: {user}")

    def on_category_btn_click(self):
        cat = self.var_category.get()
        if not cat:
            return
        self.lbl_category_stock.config(text=f"📚 [{cat}]库存: {self.backend.get_category_total_count(cat)}")
        batches = self.backend.get_batches_by_category(cat, filter_empty=self.var_hide_empty_batches.get())
        self.combo_batches['values'] = batches
        if batches:
            self.combo_batches.current(0)
            self.on_batch_selected(None)
        else:
            self.combo_batches.set("")
            self.list_raw.delete(0, tk.END)
            self.lbl_reserve_count.config(text="🍞 批次库存: 0")

    def on_batch_selected(self, event):
        cat = self.var_category.get()
        batch = self.combo_batches.get()
        if not cat or not batch:
            return
        self.refresh_groups()
        self.refresh_group_items()
        self.lbl_select_info.config(text="已选: 0")

    def refresh_groups(self):
        """刷新分组筛选按钮"""
        prev_filter = self.var_group_filter.get() if hasattr(self, 'var_group_filter') else "全部"
        for w in self.frame_group_buttons.winfo_children():
            w.destroy()
        cat = self.var_category.get()
        batch = self.combo_batches.get()
        if not cat or not batch:
            return
        groups = self.backend.get_groups(cat, batch)
        has_ungrouped = len(self.backend.get_ungrouped_items(cat, batch)) > 0 or len(self.backend.get_ungrouped_images(cat, batch)) > 0
        # 「全部」按钮
        ttk.Radiobutton(self.frame_group_buttons, text="全部", variable=self.var_group_filter,
                         value="全部", bootstyle="info-toolbutton",
                         command=self.on_group_filter_click).pack(side="left", padx=2)
        for gname, gtype, count in groups:
            icon = "📁" if gtype == "folder" else "🖼️" if gtype == "image" else "📦"
            label = f"{icon}{gname}({count})"
            ttk.Radiobutton(self.frame_group_buttons, text=label, variable=self.var_group_filter,
                             value=gname, bootstyle="info-toolbutton",
                             command=self.on_group_filter_click).pack(side="left", padx=2)
        if has_ungrouped:
            ttk.Radiobutton(self.frame_group_buttons, text="未分组", variable=self.var_group_filter,
                             value="__ungrouped__", bootstyle="secondary-toolbutton",
                             command=self.on_group_filter_click).pack(side="left", padx=2)
        # 保持之前的筛选选择（如果该分组仍然存在）
        valid_values = [w.cget("value") for w in self.frame_group_buttons.winfo_children()]
        if prev_filter in valid_values:
            self.var_group_filter.set(prev_filter)
        else:
            self.var_group_filter.set("全部")

    def on_group_filter_click(self):
        """分组筛选切换"""
        self.refresh_group_items()
        # 重命名/删除按钮仅在选中具体分组时可用
        gf = self.var_group_filter.get()
        is_specific = gf not in ("全部", "__ungrouped__")
        self.btn_rename_group.config(state="normal" if is_specific else "disabled")
        self.btn_delete_group.config(state="normal" if is_specific else "disabled")

    def refresh_group_items(self):
        """根据当前筛选刷新列表内容"""
        cat = self.var_category.get()
        batch = self.combo_batches.get()
        if not cat or not batch:
            return
        self.list_raw.delete(0, tk.END)
        self._item_display_data = []
        gf = self.var_group_filter.get()
        if gf == "全部":
            # 显示所有分组 + 未分组
            groups = self.backend.get_groups(cat, batch)
            for gname, gtype, count in groups:
                gpath = os.path.join(self.backend.dirs["RAW"], cat, batch, gname)
                items = self.backend.get_items_in_group(gpath, gtype)
                for item in items:
                    icon = "📁" if gtype == "folder" else "🖼️"
                    display = f"{icon} {item}    [{gname}]"
                    self.list_raw.insert(tk.END, display)
                    # 存储 (相对路径, 分组名, 类型) — 分组内项目用 分组名/项目名 作为相对路径
                    rel_path = f"{gname}/{item}" if gtype == "folder" else item
                    self._item_display_data.append((rel_path, gname, gtype))
            # 未分组的八位数文件夹
            ungrouped = self.backend.get_ungrouped_items(cat, batch)
            for item in ungrouped:
                display = f"📁 {item}    [未分组]"
                self.list_raw.insert(tk.END, display)
                self._item_display_data.append((item, None, "folder"))
            # 未分组的散落图片
            ungrouped_imgs = self.backend.get_ungrouped_images(cat, batch)
            for item in ungrouped_imgs:
                display = f"🖼️ {item}    [未分组]"
                self.list_raw.insert(tk.END, display)
                self._item_display_data.append((item, None, "image"))
        elif gf == "__ungrouped__":
            ungrouped = self.backend.get_ungrouped_items(cat, batch)
            for item in ungrouped:
                display = f"📁 {item}    [未分组]"
                self.list_raw.insert(tk.END, display)
                self._item_display_data.append((item, None, "folder"))
            ungrouped_imgs = self.backend.get_ungrouped_images(cat, batch)
            for item in ungrouped_imgs:
                display = f"🖼️ {item}    [未分组]"
                self.list_raw.insert(tk.END, display)
                self._item_display_data.append((item, None, "image"))
        else:
            # 筛选某个分组
            gpath = os.path.join(self.backend.dirs["RAW"], cat, batch, gf)
            gtype = self.backend.get_group_type(gpath)
            items = self.backend.get_items_in_group(gpath, gtype)
            for item in items:
                icon = "📁" if gtype == "folder" else "🖼️"
                display = f"{icon} {item}    [{gf}]"
                self.list_raw.insert(tk.END, display)
                rel_path = f"{gf}/{item}" if gtype == "folder" else item
                self._item_display_data.append((rel_path, gf, gtype))
        batch_count = len(self._item_display_data)
        self.lbl_reserve_count.config(text=f"🍞 分组库存: {batch_count}")

    def refresh_users(self):
        users = self.backend.get_users()
        if hasattr(self, 'list_users_dist'):
            self.list_users_dist.delete(0, tk.END)
            for u in users:
                self.list_users_dist.insert(tk.END, u)

    def on_list_select(self, event):
        self.lbl_select_info.config(text=f"已选: {len(self.list_raw.curselection())}")

    def select_all(self):
        self.list_raw.select_set(0, tk.END)
        self.on_list_select(None)

    def select_quick(self, count):
        self.list_raw.selection_clear(0, tk.END)
        end = min(count, self.list_raw.size())
        if end > 0:
            self.list_raw.selection_set(0, end - 1)
        self.on_list_select(None)

    def select_by_spinbox(self):
        try:
            count = int(self.spin_select_count.get())
        except ValueError:
            return
        if count < 1:
            return
        self.select_quick(count)

    def on_distribute_split(self):
        if self.worker.is_running():
            return messagebox.showwarning("提示", "有操作正在执行，请等待完成")
        cat = self.var_category.get()
        batch = self.combo_batches.get()
        raw_indices = self.list_raw.curselection()
        user_indices = self.list_users_dist.curselection()
        user_list = [self.list_users_dist.get(i) for i in user_indices]
        recovery_path = tuple(p for p in (self.var_recovery_level1.get(), self.var_recovery_level2.get()) if p)
        if not cat or not batch or not raw_indices or not user_list:
            return messagebox.showwarning("提示", "请完整选择！")
        # 从 _item_display_data 获取选中项的真实信息
        selected = [self._item_display_data[i] for i in raw_indices]
        # 按类型分组
        folder_items = [rel_path for rel_path, gname, gtype in selected if gtype == "folder"]
        # 图片按分组名分组：{gname: [item_name, ...]}
        image_by_group = {}
        for rel_path, gname, gtype in selected:
            if gtype == "image":
                image_by_group.setdefault(gname, []).append(rel_path)
        total_items = len(selected)
        total_u = len(user_list)
        # 构建确认信息
        confirm_parts = []
        if folder_items:
            confirm_parts.append(f"📁 文件夹: {len(folder_items)} 个")
        for gname, imgs in image_by_group.items():
            label = gname or "未分组"
            confirm_parts.append(f"🖼️ 图片组【{label}】: {len(imgs)} 张")
        confirm_parts.append(f"\n发送给: {', '.join(user_list)} ({total_u}人)")
        confirm_parts.append(f"下发类目: {'/'.join(recovery_path) if recovery_path else '未分类'}")
        if not messagebox.askyesno("确认发送", "\n".join(confirm_parts)):
            return

        def _task(msg_queue=None, cancel_flag=None):
            succ = 0
            fail = 0
            if self.var_random_shuffle.get():
                random.shuffle(folder_items)
                for gname in image_by_group:
                    random.shuffle(image_by_group[gname])
            # 1. 文件夹均分（rel_path 已包含分组目录，如 "【项目A】/02120001"）
            if folder_items:
                per = len(folder_items) // total_u
                rem = len(folder_items) % total_u
                curr = 0
                for i, user in enumerate(user_list):
                    if cancel_flag and cancel_flag():
                        break
                    take = per + (1 if i < rem else 0)
                    if take == 0:
                        continue
                    cnt, failed, _ = self.backend.distribute_specific(
                        user, cat, batch, folder_items[curr:curr + take],
                        msg_queue=msg_queue, cancel_flag=cancel_flag,
                        recovery_path=recovery_path,
                    )
                    curr += take
                    succ += cnt
                    fail += failed
                # 清理可能变空的分组目录
                batch_path = os.path.join(self.backend.dirs["RAW"], cat, batch)
                for gname in set(gn for _, gn, gt in selected if gn and gt == "folder"):
                    gpath = os.path.join(batch_path, gname)
                    self.backend._cleanup_empty_group(gpath)
            # 2. 图片组均分（按分组分别发送）
            for gname, imgs in image_by_group.items():
                per_img = len(imgs) // total_u
                rem_img = len(imgs) % total_u
                curr_img = 0
                for i, user in enumerate(user_list):
                    if cancel_flag and cancel_flag():
                        break
                    take = per_img + (1 if i < rem_img else 0)
                    if take == 0:
                        continue
                    cnt, failed, _ = self.backend.distribute_image_group(
                        user, cat, batch, gname,
                        imgs[curr_img:curr_img + take],
                        msg_queue=msg_queue, cancel_flag=cancel_flag,
                        recovery_path=recovery_path,
                    )
                    curr_img += take
                    succ += cnt
                    fail += failed
            return {"success": succ, "failed": fail, "total": total_items}

        def _on_complete(result):
            messagebox.showinfo("完成", f"成功移动 {result['success']} 个。\n失败 {result['failed']} 个。")
            self.on_category_btn_click()

        self._pending_complete_handler = _on_complete
        self._set_buttons_enabled(False)
        self.append_log("--- 启动均分 ---")
        self.worker.start(_task)

    def refresh_harvest_status(self):
        for item in self.tree_status.get_children():
            self.tree_status.delete(item)
        stats = self.backend.get_done_stats()
        valid_users = []
        for s in stats:
            if s["total_done"] > 0 or s["pending"] > 0 or s["distributed_today"] > 0:
                valid_users.append(s["user"])
                self.tree_status.insert("", "end", values=(s["user"], s["distributed_today"], s["normal"], s["rework"], s["abandoned"], s["pending"], s["total_done"]))
        self.combo_harvest_user['values'] = valid_users
        if valid_users and not self.combo_harvest_user.get():
            self.combo_harvest_user.current(0)

    def on_harvest_all(self):
        if self.worker.is_running():
            return messagebox.showwarning("提示", "有操作正在执行，请等待完成")
        if not messagebox.askyesno("确认", "全员回收？"):
            return

        def _task(msg_queue=None, cancel_flag=None):
            return self.backend.harvest(
                None, self.var_harvest_collect_unfinished.get(),
                None, self.var_separate_psd.get(),
                msg_queue=msg_queue, cancel_flag=cancel_flag
            )

        self._pending_complete_handler = self._harvest_complete
        self._set_buttons_enabled(False)
        self.worker.start(_task)

    def on_harvest_single(self):
        if self.worker.is_running():
            return messagebox.showwarning("提示", "有操作正在执行，请等待完成")
        u = self.combo_harvest_user.get()
        if not u or not messagebox.askyesno("确认", f"回收 {u}？"):
            return

        def _task(msg_queue=None, cancel_flag=None):
            return self.backend.harvest(
                u, self.var_harvest_collect_unfinished.get(),
                None, self.var_separate_psd.get(),
                msg_queue=msg_queue, cancel_flag=cancel_flag
            )

        self._pending_complete_handler = self._harvest_complete
        self._set_buttons_enabled(False)
        self.worker.start(_task)

    def refresh_dates(self):
        ds = self.backend.get_history_dates()
        self.combo_dates['values'] = ds
        self.combo_qa_date['values'] = ds
        if ds:
            self.combo_dates.current(0)
            self.on_date_selected(None)

    def on_date_selected(self, event):
        d = self.combo_dates.get()
        if d:
            stats = self.backend.get_history_stats(d)
            self.lbl_hist_normal.config(text=f"✅ 新标: {stats['total_new']}")
            self.lbl_hist_rework.config(text=f"🔧 返修: {stats['total_rework']}")
            self.lbl_hist_abandon.config(text=f"🗑️ 废料: {stats['abandoned']}")
            self.lbl_hist_total.config(text=f"合计: {stats['grand_total']}")
            for item in self.tree_history.get_children():
                self.tree_history.delete(item)
            for u in stats['user_breakdown']:
                self.tree_history.insert("", "end", values=(u['user'], u['new'], u['rework'], u['subtotal']))

    def open_qc_folder(self, fn):
        p = self.backend.get_qc_subpath(fn, self.combo_dates.get())
        if os.path.exists(p):
            self.open_folder(p)
        else:
            messagebox.showinfo("提示", "无数据")

    def on_qa_mode_change(self):
        self.refresh_qa_user_list()

    def on_qa_date_select(self, event):
        self.refresh_qa_user_list()

    def refresh_qa_user_list(self):
        d = self.combo_qa_date.get()
        m = self.var_qa_mode.get()
        if d:
            self.list_qa_users.delete(0, tk.END)
            for u in self.backend.get_users_in_history_date_by_mode(d, m):
                self.list_qa_users.insert(tk.END, u)
            self.lbl_qa_info.config(text="已选: 0")

    def on_qa_user_select_change(self, event):
        d = self.combo_qa_date.get()
        m = self.var_qa_mode.get()
        idxs = self.list_qa_users.curselection()
        if d and idxs:
            users = [self.list_qa_users.get(i).split(" (")[0] for i in idxs]
            tot = sum([self.backend.get_qa_task_count_by_mode(d, u, m) for u in users])
            self.lbl_qa_info.config(text=f"已选: {len(users)} 人 | 库存: {tot} 个")

    def refresh_qa_targets(self):
        us = self.backend.get_users()
        qas = [u for u in us if "验收" in u]
        ots = [u for u in us if "验收" not in u]
        self.combo_target_qa['values'] = qas + ots
        if qas or ots:
            self.combo_target_qa.current(0)

    def on_choose_qa_root(self):
        initial = self.var_qa_root.get().strip() if hasattr(self, "var_qa_root") else ""
        if not initial and self.backend.project_root:
            initial = os.path.join(self.backend.project_root, "04_Quality_Check", "质检工作台")
        selected = filedialog.askdirectory(title="选择质检项目目录", initialdir=initial or os.path.expanduser("~"))
        if not selected:
            return
        try:
            root = ensure_qc_root(selected)
        except OSError as exc:
            return messagebox.showerror("创建质检目录失败", str(exc))
        self.var_qa_root.set(str(root))
        self.save_config()
        self.append_log(f"✅ 已设置质检目录: {root}")

    def on_start_qc(self):
        if not hasattr(self, "var_qa_root"):
            return
        root_value = self.var_qa_root.get().strip()
        if not root_value:
            if not self.backend.project_root:
                return messagebox.showwarning("提示", "请先连接项目目录或选择质检目录。")
            root_value = os.path.join(self.backend.project_root, "04_Quality_Check", "质检工作台")
            self.var_qa_root.set(root_value)
        launcher = find_qc_launcher()
        if launcher is None:
            return messagebox.showerror(
                "未找到质检工具",
                "未找到 DataTangQCTool-Launcher.exe。\n\n"
                "请从 GitHub Releases 下载“DataGuard 管理员套件”，并保持质检启动器与管理员端在同一文件夹。",
            )
        try:
            qc_root = ensure_qc_root(root_value)
            launch_qc(qc_root, launcher)
        except (OSError, FileNotFoundError) as exc:
            return messagebox.showerror("启动质检失败", str(exc))
        self.var_qa_root.set(str(qc_root))
        self.save_config()
        self.append_log(f"▶ 已启动质检工具: {qc_root}")

    def on_qa_distribute(self):
        if self.worker.is_running():
            return messagebox.showwarning("提示", "有操作正在执行，请等待完成")
        d = self.combo_qa_date.get()
        m = self.var_qa_mode.get()
        t = self.combo_target_qa.get()
        idxs = self.list_qa_users.curselection()
        if not d or not idxs or not t:
            return messagebox.showwarning("提示", "请完整选择！")
        srcs = [self.list_qa_users.get(i).split(" (")[0] for i in idxs]
        if not messagebox.askyesno("确认", f"下发给 {t}？"):
            return

        def _task(msg_queue=None, cancel_flag=None):
            tot = 0
            for u in srcs:
                if cancel_flag and cancel_flag():
                    break
                cnt, msg = self.backend.distribute_to_internal_qa(d, u, t, m, msg_queue=msg_queue, cancel_flag=cancel_flag)
                tot += cnt
            return {"total": tot}

        def _on_complete(result):
            messagebox.showinfo("完成", f"下发完毕，共 {result['total']} 个。")

        self._pending_complete_handler = _on_complete
        self._set_buttons_enabled(False)
        self.worker.start(_task)

    def refresh_log_list(self):
        for item in self.tree_logs.get_children():
            self.tree_logs.delete(item)
        logs = self.backend.get_log_files_list()
        for log in logs:
            self.tree_logs.insert("", "end", iid=log["path"], values=(log["date"], log["filename"], log["size"]))

    def on_log_double_click(self, event):
        self.on_open_log_click()

    def on_open_log_click(self):
        sel = self.tree_logs.selection()
        if sel:
            success, msg = self.open_file(sel[0])
            if success:
                self.append_log(f"📂 已打开日志: {os.path.basename(sel[0])}")
            else:
                messagebox.showerror("错误", msg)

    def open_folder(self, path):
        """打开文件夹（平台 UI 操作）"""
        if os.path.exists(path):
            try:
                if platform.system() == "Windows":
                    os.startfile(path)
                else:
                    subprocess.Popen(["open", path])
            except OSError as e:
                self.append_log(f"⚠️ 打开文件夹失败: {e}")

    def open_file(self, file_path):
        """打开文件（平台 UI 操作）"""
        if os.path.exists(file_path):
            try:
                if platform.system() == "Windows":
                    os.startfile(file_path)
                else:
                    subprocess.Popen(["open", file_path])
                return True, "已打开"
            except OSError as e:
                return False, str(e)
        return False, "文件不存在"
