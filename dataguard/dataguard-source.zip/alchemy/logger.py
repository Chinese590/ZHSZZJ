# 应用日志器 — 按天轮转，保留 7 天

import logging
import os
from logging.handlers import TimedRotatingFileHandler


def setup_logger(log_dir):
    """Create or rebind the application logger to ``log_dir/app.log``."""
    os.makedirs(log_dir, exist_ok=True)
    logger = logging.getLogger("alchemy")
    logger.setLevel(logging.DEBUG)
    logger.propagate = False

    log_file = os.path.abspath(os.path.join(log_dir, "app.log"))
    active_files = [
        os.path.abspath(getattr(handler, "baseFilename", ""))
        for handler in logger.handlers
    ]
    if len(logger.handlers) == 1 and active_files == [log_file]:
        return logger

    for handler in list(logger.handlers):
        handler.close()
        logger.removeHandler(handler)

    handler = TimedRotatingFileHandler(
        log_file, when="midnight", backupCount=7, encoding="utf-8"
    )
    handler.setFormatter(logging.Formatter(
        "%(asctime)s [%(levelname)s] %(message)s", datefmt="%Y-%m-%d %H:%M:%S"
    ))
    logger.addHandler(handler)
    return logger
