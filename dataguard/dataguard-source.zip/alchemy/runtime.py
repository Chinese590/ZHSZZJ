"""Runtime path helpers for source and PyInstaller builds."""

from __future__ import annotations

import os
import sys


def application_dir() -> str:
    """Return the writable directory that contains the application launcher."""
    if getattr(sys, "frozen", False):
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def writable_path(*parts: str) -> str:
    """Build a path rooted beside the executable (or project root in source mode)."""
    return os.path.join(application_dir(), *parts)
