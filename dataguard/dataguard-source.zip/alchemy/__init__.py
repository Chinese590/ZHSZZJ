# alchemy/__init__.py
from .backend import AlchemyBackend

__all__ = ["AlchemyBackend", "AlchemyApp"]


def __getattr__(name):
    if name == "AlchemyApp":
        from .app import AlchemyApp
        return AlchemyApp
    raise AttributeError(name)
