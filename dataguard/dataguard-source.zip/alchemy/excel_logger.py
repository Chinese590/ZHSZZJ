import datetime
import os

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.worksheet.table import Table, TableStyleInfo


DETAIL_HEADERS = ["时间", "操作类型", "标注员", "一级类目", "二级类目", "任务ID/包名", "内容类型", "图片数量", "任务数量", "新标/返修", "结果", "备注", "状态"]
SUMMARY_HEADERS = ["标注员", "一级类目", "二级类目", "下发图片数", "下发任务数", "新标回收数", "返修回收数", "失败数"]


class ExcelOperationLogger:
    def __init__(self, log_dir):
        self.log_dir = log_dir

    def today_path(self):
        date = datetime.datetime.now().strftime("%Y-%m-%d")
        return os.path.join(self.log_dir, f"操作日志_{date}.xlsx")

    def append(self, *, action, user, task_id, result, category1="未分类", category2="-",
               content_type="任务文件夹", image_count=0, task_count=1,
               work_type="新标", remark="-", status="-"):
        os.makedirs(self.log_dir, exist_ok=True)
        path = self.today_path()
        tmp = path + ".tmp.xlsx"
        wb = None
        try:
            wb = load_workbook(path) if os.path.exists(path) else self._new_workbook()
            detail = wb["明细"]
            detail.append([datetime.datetime.now().strftime("%H:%M:%S"), action, user,
                           category1 or "未分类", category2 or "-", task_id, content_type,
                           int(image_count or 0), int(task_count or 0), work_type, result, remark, status])
            self._refresh_detail_table(detail)
            self._rebuild_summary(wb)
            wb.save(tmp)
            wb.close()
            wb = None
            os.replace(tmp, path)
            return path
        finally:
            if wb is not None:
                wb.close()
            if os.path.exists(tmp):
                try:
                    os.remove(tmp)
                except OSError:
                    pass

    @staticmethod
    def _new_workbook():
        wb = Workbook()
        summary = wb.active
        summary.title = "总结"
        detail = wb.create_sheet("明细")
        summary.append(SUMMARY_HEADERS)
        detail.append(DETAIL_HEADERS)
        for sheet in (summary, detail):
            sheet.freeze_panes = "A2"
            for cell in sheet[1]:
                cell.font = Font(name="Microsoft YaHei", bold=True, color="FFFFFF")
                cell.fill = PatternFill("solid", fgColor="1F4E78")
                cell.alignment = Alignment(horizontal="center")
        for index, width in enumerate((12, 14, 12, 14, 14, 20, 14, 12, 12, 12, 10, 30, 14), 1):
            detail.column_dimensions[detail.cell(1, index).column_letter].width = width
        return wb

    @staticmethod
    def _refresh_detail_table(detail):
        ref = f"A1:M{detail.max_row}"
        if "明细表" in detail.tables:
            detail.tables["明细表"].ref = ref
        else:
            table = Table(displayName="明细表", ref=ref)
            table.tableStyleInfo = TableStyleInfo(name="TableStyleMedium2", showRowStripes=True)
            detail.add_table(table)
        detail.auto_filter.ref = ref

    @staticmethod
    def _rebuild_summary(wb):
        summary = wb["总结"]
        if summary.max_row > 1:
            summary.delete_rows(2, summary.max_row - 1)
        detail = wb["明细"]
        keys = sorted({(detail.cell(r, 3).value, detail.cell(r, 4).value, detail.cell(r, 5).value)
                       for r in range(2, detail.max_row + 1)})
        for row, (user, cat1, cat2) in enumerate(keys, 2):
            summary.cell(row, 1, user)
            summary.cell(row, 2, cat1)
            summary.cell(row, 3, cat2)
            criteria = f'明细!$C:$C,$A{row},明细!$D:$D,$B{row},明细!$E:$E,$C{row}'
            summary.cell(row, 4, f'=SUMIFS(明细!$H:$H,{criteria},明细!$B:$B,"素材下发",明细!$K:$K,"成功")')
            summary.cell(row, 5, f'=SUMIFS(明细!$I:$I,{criteria},明细!$B:$B,"素材下发",明细!$K:$K,"成功")')
            summary.cell(row, 6, f'=SUMIFS(明细!$I:$I,{criteria},明细!$B:$B,"产物回收",明细!$K:$K,"成功",明细!$M:$M,"<>*废弃*")')
            summary.cell(row, 7, f'=SUMIFS(明细!$I:$I,{criteria},明细!$B:$B,"返修回收",明细!$K:$K,"成功",明细!$M:$M,"<>*废弃*")')
            summary.cell(row, 8, f'=COUNTIFS({criteria},明细!$K:$K,"失败")')
        summary.auto_filter.ref = f"A1:H{max(summary.max_row, 1)}"
        for index in range(1, 9):
            summary.column_dimensions[summary.cell(1, index).column_letter].width = 14
