@echo off
setlocal
cd /d "%~dp0"
if not exist "DataGuard.exe" (
  echo DataGuard.exe was not found. The portable package may be incomplete.
  pause
  exit /b 1
)
start "" "%~dp0DataGuard.exe"
exit /b %errorlevel%
