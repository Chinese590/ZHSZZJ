@echo off
call "%~dp0Start_DataGuard.bat"
exit /b %errorlevel%
