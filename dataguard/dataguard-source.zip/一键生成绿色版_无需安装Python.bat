@echo off
call "%~dp0BUILD_PORTABLE.bat"
exit /b %errorlevel%
