@echo off
setlocal
cd /d "%~dp0"
echo DataGuard Windows 10 portable builder
echo.
powershell.exe -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0build_windows_portable_auto.ps1"
if errorlevel 1 (
  echo.
  echo BUILD FAILED. Review the error shown above.
  pause
  exit /b 1
)
echo.
echo BUILD COMPLETED.
echo Send the ZIP file from the release folder to other computers.
pause
exit /b 0
