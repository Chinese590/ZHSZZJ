"""DataGuard administrator entry point."""

from DataGuard181 import main


if __name__ == "__main__":
    main()
