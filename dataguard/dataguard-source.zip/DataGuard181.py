# DataGuard181.py - v1.9.0 管理员入口兼容文件
# 实际实现位于 alchemy/ 包中

from __future__ import annotations

import datetime
import os
import traceback

import ttkbootstrap as ttk

from alchemy import AlchemyApp
from alchemy.constants import UI_THEME
from alchemy.runtime import writable_path


def _write_startup_error(exc: BaseException) -> str:
    log_dir = writable_path("logs")
    os.makedirs(log_dir, exist_ok=True)
    log_path = os.path.join(log_dir, "startup_error.log")
    with open(log_path, "a", encoding="utf-8") as f:
        f.write("=" * 72 + "\n")
        f.write(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + "\n")
        traceback.print_exception(type(exc), exc, exc.__traceback__, file=f)
    return log_path


def main() -> None:
    root = ttk.Window(themename=UI_THEME)
    AlchemyApp(root)
    root.mainloop()


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        traceback.print_exc()
        try:
            log_path = _write_startup_error(exc)
            message = f"DataGuard 启动失败。错误日志：\n{log_path}"
        except Exception:
            message = "DataGuard 启动失败，请联系管理员。"
        try:
            import tkinter.messagebox as messagebox

            messagebox.showerror("DataGuard 启动失败", message)
        except Exception:
            pass
