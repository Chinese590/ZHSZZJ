# DataGuard181.py - v1.9.20 管理员入口兼容文件
# 实际实现位于 alchemy/ 包中

from __future__ import annotations

import datetime
import os
import traceback

import ttkbootstrap as ttk

from alchemy import AlchemyApp
from alchemy.constants import UI_THEME
from alchemy.runtime import writable_path


def _write_startup_error(exc: BaseException) -> str:
    log_dir = writable_path("logs")
    os.makedirs(log_dir, exist_ok=True)
    log_path = os.path.join(log_dir, "startup_error.log")
    with open(log_path, "a", encoding="utf-8") as f:
        f.write("=" * 72 + "\n")
        f.write(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + "\n")
        traceback.print_exception(type(exc), exc, exc.__traceback__, file=f)
    return log_path


def main() -> None:
    root = ttk.Window(themename=UI_THEME)
    guide = writable_path("管理员首次使用说明已读.flag")
    if not os.path.exists(guide):
        from tkinter import messagebox
        messagebox.showinfo("DataGuard 管理端快速开始", "首次使用只需 4 步：\n1. 点击“挂载路径”选择项目目录；\n2. 点击“创建目录”；\n3. 在“素材分发”导入图片、选择人员和每人数量后均分发送；\n4. 在“产物回收”回收，或在“样本”点击“直接开始质检”。\n质检启动器必须与本程序放在同一文件夹。")
        try:
            open(guide, "w", encoding="utf-8").close()
        except OSError:
            pass
    AlchemyApp(root)
    root.mainloop()


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        traceback.print_exc()
        try:
            log_path = _write_startup_error(exc)
            message = f"DataGuard 启动失败。错误日志：\n{log_path}"
        except Exception:
            message = "DataGuard 启动失败，请联系管理员。"
        try:
            import tkinter.messagebox as messagebox

            messagebox.showerror("DataGuard 启动失败", message)
        except Exception:
            pass
