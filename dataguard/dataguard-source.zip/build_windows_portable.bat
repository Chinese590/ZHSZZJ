@echo off
setlocal
cd /d "%~dp0"
where python >nul 2>nul
if errorlevel 1 (
  echo Python was not found. Use BUILD_PORTABLE.bat instead.
  pause
  exit /b 1
)
python -m pip install --disable-pip-version-check -r requirements-build.txt
if errorlevel 1 exit /b 1
python -m pytest -q
if errorlevel 1 exit /b 1
python -m PyInstaller --noconfirm --clean DataGuard.spec
if errorlevel 1 exit /b 1
echo Build output: dist\DataGuard
pause
