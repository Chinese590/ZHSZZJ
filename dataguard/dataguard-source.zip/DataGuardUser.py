"""Simplified DataGuard workstation for annotators."""

from __future__ import annotations

import json
import os
import platform
import shutil
import subprocess
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox

import ttkbootstrap as ttk

from alchemy.constants import DIR_DIST, USER_DONE, USER_REWORK, USER_TODO, UI_THEME
from alchemy.runtime import writable_path
from alchemy.user_tasks import count_task_folders, safe_relative_child

CONFIG_PATH = writable_path("dataguard_user_config.json")



class UserWorkbench:
    def __init__(self, root: ttk.Window):
        self.root = root
        self.root.title("DataGuard 用户工作台")
        self.root.geometry("620x500")
        self.root.minsize(580, 460)
        self.project_var = tk.StringVar()
        self.user_var = tk.StringVar()
        self.status_var = tk.StringVar(value="请选择项目目录和姓名")
        self.todo_var = tk.StringVar(value="待办 0")
        self.done_var = tk.StringVar(value="已提交 0")
        self.rework_var = tk.StringVar(value="返修提交 0")
        self._build_ui()
        self._load_config()
        self._refresh_users()
        self._refresh_counts()
        self.root.after(3000, self._periodic_refresh)

    def _build_ui(self) -> None:
        outer = ttk.Frame(self.root, padding=20)
        outer.pack(fill="both", expand=True)

        ttk.Label(outer, text="DataGuard 用户工作台", font=("Microsoft YaHei", 18, "bold")).pack(anchor="w")
        ttk.Label(outer, text="只显示本人任务，不包含管理员功能。", bootstyle="secondary").pack(anchor="w", pady=(2, 18))

        project_row = ttk.Frame(outer)
        project_row.pack(fill="x", pady=5)
        ttk.Label(project_row, text="项目目录：", width=10).pack(side="left")
        ttk.Entry(project_row, textvariable=self.project_var, state="readonly").pack(side="left", fill="x", expand=True, padx=8)
        ttk.Button(project_row, text="选择", command=self._choose_project).pack(side="right")

        user_row = ttk.Frame(outer)
        user_row.pack(fill="x", pady=5)
        ttk.Label(user_row, text="当前用户：", width=10).pack(side="left")
        self.user_combo = ttk.Combobox(user_row, textvariable=self.user_var, state="readonly")
        self.user_combo.pack(side="left", fill="x", expand=True, padx=8)
        self.user_combo.bind("<<ComboboxSelected>>", lambda _event: self._on_user_changed())
        ttk.Button(user_row, text="刷新", command=self._refresh_all).pack(side="right")

        summary = ttk.Frame(outer, padding=(0, 18))
        summary.pack(fill="x")
        for variable, style in ((self.todo_var, "primary"), (self.done_var, "success"), (self.rework_var, "warning")):
            ttk.Label(summary, textvariable=variable, bootstyle=f"{style}-inverse", anchor="center", padding=12).pack(side="left", fill="x", expand=True, padx=5)

        actions = ttk.Labelframe(outer, text="我的任务", padding=15)
        actions.pack(fill="both", expand=True)
        ttk.Button(actions, text="打开待办目录", bootstyle="primary", command=lambda: self._open_user_folder(USER_TODO)).pack(fill="x", pady=5, ipady=7)
        ttk.Button(actions, text="提交已完成任务", bootstyle="success", command=lambda: self._submit_task(USER_DONE)).pack(fill="x", pady=5, ipady=7)
        ttk.Button(actions, text="提交返修任务", bootstyle="warning", command=lambda: self._submit_task(USER_REWORK)).pack(fill="x", pady=5, ipady=7)
        ttk.Button(actions, text="打开工具箱", bootstyle="secondary", command=lambda: self._open_user_folder("Toolbox")).pack(fill="x", pady=5)

        ttk.Label(outer, textvariable=self.status_var, bootstyle="secondary", wraplength=560).pack(anchor="w", pady=(12, 0))

    def _load_config(self) -> None:
        try:
            data = json.loads(Path(CONFIG_PATH).read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return
        self.project_var.set(str(data.get("project_root", "")))
        self.user_var.set(str(data.get("username", "")))

    def _save_config(self) -> None:
        data = {"project_root": self.project_var.get(), "username": self.user_var.get()}
        Path(CONFIG_PATH).write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    def _choose_project(self) -> None:
        selected = filedialog.askdirectory(initialdir=self.project_var.get() or str(Path.home()))
        if not selected:
            return
        if not (Path(selected) / DIR_DIST).is_dir():
            messagebox.showerror("目录错误", f"所选目录中没有 {DIR_DIST}。")
            return
        self.project_var.set(selected)
        self._refresh_users()
        self._save_config()
        self._refresh_counts()

    def _users_root(self) -> Path | None:
        value = self.project_var.get().strip()
        if not value:
            return None
        return Path(value) / DIR_DIST

    def _user_root(self) -> Path | None:
        users_root = self._users_root()
        username = self.user_var.get().strip()
        if users_root is None or not username:
            return None
        candidate = users_root / username
        return candidate if candidate.is_dir() else None

    def _refresh_users(self) -> None:
        users_root = self._users_root()
        users = []
        if users_root and users_root.is_dir():
            users = sorted((item.name for item in users_root.iterdir() if item.is_dir()), key=str.lower)
        self.user_combo["values"] = users
        if self.user_var.get() not in users:
            self.user_var.set(users[0] if users else "")

    def _on_user_changed(self) -> None:
        self._save_config()
        self._refresh_counts()

    def _refresh_counts(self) -> None:
        user_root = self._user_root()
        if user_root is None:
            self.todo_var.set("待办 0")
            self.done_var.set("已提交 0")
            self.rework_var.set("返修提交 0")
            self.status_var.set("请选择有效项目目录和姓名")
            return
        self.todo_var.set(f"待办 {count_task_folders(user_root / USER_TODO)}")
        self.done_var.set(f"已提交 {count_task_folders(user_root / USER_DONE)}")
        self.rework_var.set(f"返修提交 {count_task_folders(user_root / USER_REWORK)}")
        self.status_var.set(f"当前：{self.user_var.get()}  |  {self.project_var.get()}")

    def _refresh_all(self) -> None:
        self._refresh_users()
        self._refresh_counts()

    def _periodic_refresh(self) -> None:
        self._refresh_counts()
        self.root.after(3000, self._periodic_refresh)

    def _open_user_folder(self, folder_name: str) -> None:
        user_root = self._user_root()
        if user_root is None:
            messagebox.showwarning("提示", "请先选择项目目录和姓名。")
            return
        target = user_root / folder_name
        target.mkdir(parents=True, exist_ok=True)
        try:
            if platform.system() == "Windows":
                os.startfile(str(target))  # type: ignore[attr-defined]
            elif platform.system() == "Darwin":
                subprocess.Popen(["open", str(target)])
            else:
                subprocess.Popen(["xdg-open", str(target)])
        except OSError as exc:
            messagebox.showerror("打开失败", str(exc))

    def _submit_task(self, destination_name: str) -> None:
        user_root = self._user_root()
        if user_root is None:
            messagebox.showwarning("提示", "请先选择项目目录和姓名。")
            return
        todo_root = user_root / USER_TODO
        todo_root.mkdir(parents=True, exist_ok=True)
        selected = filedialog.askdirectory(title="选择需要提交的任务文件夹", initialdir=str(todo_root))
        if not selected:
            return
        try:
            relative = safe_relative_child(todo_root, Path(selected))
            destination = user_root / destination_name / relative
            if destination.exists():
                raise FileExistsError(f"目标已存在：{destination}")
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(selected, destination)
            qc_status = "待质检" if destination_name == USER_DONE else "返修提交"
            qc_root = Path(self.project_var.get()) / "04_Quality_Check" / "质检工作台" / qc_status / self.user_var.get() / relative
            if qc_root.exists():
                raise FileExistsError(f"质检目录中已存在：{qc_root}")
            qc_root.parent.mkdir(parents=True, exist_ok=True)
            shutil.copytree(destination, qc_root)
        except (OSError, ValueError) as exc:
            messagebox.showerror("提交失败", str(exc))
            return
        self.status_var.set(f"提交成功：{relative}")
        self._refresh_counts()


def main() -> None:
    root = ttk.Window(themename=UI_THEME)
    UserWorkbench(root)
    root.mainloop()


if __name__ == "__main__":
    main()
