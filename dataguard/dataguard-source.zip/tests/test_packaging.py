from pathlib import Path
import unittest


class PackagingFilesTests(unittest.TestCase):
    def setUp(self):
        self.root = Path(__file__).parents[1]

    def test_portable_build_files_exist(self):
        required = [
            "DataGuard.spec",
            "requirements-build.txt",
            "build_windows_portable.bat",
            "BUILD_PORTABLE.bat",
            "一键生成绿色版_无需安装Python.bat",
            "build_windows_portable_auto.ps1",
            "release_docs/使用说明.txt",
            "release_docs/版本说明.txt",
            "release_docs/启动_DataGuard.bat",
            "release_docs/User_Guide.txt",
            "release_docs/Release_Notes.txt",
            "release_docs/Start_DataGuard.bat",
        ]
        for relative in required:
            with self.subTest(relative=relative):
                self.assertTrue((self.root / relative).is_file())

    def test_spec_uses_onedir_windowed_build(self):
        text = (self.root / "DataGuard.spec").read_text(encoding="utf-8")
        self.assertIn("COLLECT", text)
        self.assertIn("console=False", text)
        self.assertIn("name='DataGuard'", text)

    def test_build_script_runs_tests_before_pyinstaller(self):
        text = (self.root / "build_windows_portable.bat").read_text(encoding="utf-8")
        self.assertLess(text.index("pytest"), text.index("PyInstaller"))
        self.assertIn("PyInstaller", text)

    def test_windows_powershell_51_build_scripts_are_ascii_safe(self):
        for relative in [
            "build_windows_portable_auto.ps1",
            "BUILD_PORTABLE.bat",
        ]:
            with self.subTest(relative=relative):
                data = (self.root / relative).read_bytes()
                self.assertFalse(data.startswith(b"\xef\xbb\xbf"))
                self.assertTrue(data.isascii())

    def test_auto_builder_bootstraps_registry_free_managed_python(self):
        text = (self.root / "build_windows_portable_auto.ps1").read_text(encoding="utf-8")
        self.assertIn("uv-x86_64-pc-windows-msvc.zip", text)
        self.assertIn("releases.astral.sh", text)
        self.assertIn("github.com/astral-sh/uv/releases", text)
        self.assertIn("UV_PYTHON_INSTALL_DIR", text)
        self.assertIn("UV_PYTHON_NO_REGISTRY", text)
        self.assertIn("uv python install", text)
        self.assertIn("uv venv", text)
        self.assertNotIn("python-3.11.9-amd64.exe", text)
        self.assertNotIn("Start-Process -FilePath $installer", text)
        self.assertIn("python -m pytest", text)
        self.assertIn("python -m PyInstaller", text)
        self.assertLess(text.index("python -m pytest"), text.index("python -m PyInstaller"))

    def test_auto_builder_validates_tkinter_before_build(self):
        text = (self.root / "build_windows_portable_auto.ps1").read_text(encoding="utf-8")
        self.assertIn("import tkinter", text)
        self.assertIn("Build Python validation failed", text)


if __name__ == "__main__":
    unittest.main()
