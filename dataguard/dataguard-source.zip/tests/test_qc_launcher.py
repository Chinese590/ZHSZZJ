import os
from pathlib import Path

from alchemy.qc_launcher import QC_STATUS_FOLDERS, ensure_qc_root, find_qc_launcher


def test_ensure_qc_root_creates_required_status_directories(tmp_path: Path):
    root = ensure_qc_root(tmp_path / "qc")
    assert root.is_dir()
    assert all((root / name).is_dir() for name in QC_STATUS_FOLDERS)


def test_find_qc_launcher_prefers_explicit_environment_path(tmp_path: Path, monkeypatch):
    launcher = tmp_path / "DataTangQCTool-Launcher.exe"
    launcher.write_bytes(b"MZ")
    monkeypatch.setenv("DATATANG_QC_LAUNCHER", str(launcher))
    assert find_qc_launcher() == launcher.resolve()
