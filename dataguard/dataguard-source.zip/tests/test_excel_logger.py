import tempfile
import unittest
from unittest.mock import Mock

from openpyxl import load_workbook

from alchemy.excel_logger import ExcelOperationLogger
from alchemy.backend import AlchemyBackend


class ExcelLoggerTests(unittest.TestCase):
    def test_workbook_contains_summary_and_detail_with_formulas(self):
        with tempfile.TemporaryDirectory() as temp:
            logger = ExcelOperationLogger(temp)
            logger.append(
                action="素材下发", user="张三", task_id="图片包_1", result="成功",
                category1="一期", category2="人+物", content_type="图片包",
                image_count=35, task_count=1, work_type="新标", remark="测试",
            )
            wb = load_workbook(logger.today_path(), data_only=False)
            self.assertEqual(wb.sheetnames, ["总结", "明细"])
            self.assertEqual(wb["明细"].cell(2, 8).value, 35)
            self.assertEqual(wb["总结"].cell(2, 1).value, "张三")
            self.assertTrue(str(wb["总结"].cell(2, 4).value).startswith("=SUMIFS("))

    def test_summary_formula_excludes_abandoned_status(self):
        with tempfile.TemporaryDirectory() as temp:
            logger = ExcelOperationLogger(temp)
            logger.append(action="产物回收", user="张三", task_id="12345678【废弃】",
                          result="成功", status="新标废弃", task_count=1)
            wb = load_workbook(logger.today_path(), data_only=False)
            self.assertIn("<>*废弃*", wb["总结"].cell(2, 6).value)

    def test_failed_excel_row_is_replayed_on_next_write(self):
        with tempfile.TemporaryDirectory() as temp:
            backend = AlchemyBackend()
            backend.set_root(temp)
            real_logger = backend.excel_logger
            backend.excel_logger = Mock()
            backend.excel_logger.append.side_effect = OSError("占用")
            self.assertFalse(backend.write_csv_log("素材下发", "张三", "包1", "常规素材", "成功", image_count=3))
            backend.excel_logger = real_logger
            self.assertTrue(backend.write_csv_log("素材下发", "张三", "包2", "常规素材", "成功", image_count=2))
            wb = load_workbook(real_logger.today_path(), data_only=False)
            self.assertEqual(wb["明细"].max_row, 3)
            wb.close()
            self.assertFalse(__import__("os").path.exists(__import__("os").path.join(temp, "05_System_Logs", "日志待补写.jsonl")))
            backend.close()


if __name__ == "__main__":
    unittest.main()
