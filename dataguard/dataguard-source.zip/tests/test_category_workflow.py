import datetime
import os
import tempfile
import unittest

from alchemy.backend import AlchemyBackend
from alchemy.constants import DATE_FMT, QC_NEW, USER_DONE, USER_TODO


class CategoryWorkflowTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.backend = AlchemyBackend()
        self.backend.set_root(self.temp.name)
        self.backend.init_directories()
        self.backend.create_user_folders("张三")
        self.backend.add_recovery_category("一期", "人+物")
        os.makedirs(os.path.join(self.backend.dirs["RAW"], "人体", "20260722"), exist_ok=True)

    def tearDown(self):
        self.backend.close()
        self.temp.cleanup()

    def test_folder_distribution_targets_selected_category(self):
        src = os.path.join(self.backend.dirs["RAW"], "人体", "20260722", "12345678")
        os.makedirs(src)
        count, failed, _ = self.backend.distribute_specific(
            "张三", "人体", "20260722", ["12345678"], recovery_path=("一期", "人+物")
        )
        self.assertEqual((count, failed), (1, 0))
        self.assertTrue(os.path.isdir(os.path.join(self.backend.get_user_path("张三"), USER_TODO, "一期", "人+物", "12345678")))

    def test_image_distribution_records_actual_image_count(self):
        src = os.path.join(self.backend.dirs["RAW"], "人体", "20260722")
        for name in ("a.jpg", "b.jpg", "c.jpg"):
            with open(os.path.join(src, name), "wb") as f:
                f.write(b"x")
        count, failed, pack = self.backend.distribute_image_group(
            "张三", "人体", "20260722", None, ["a.jpg", "b.jpg", "c.jpg"],
            recovery_path=("一期", "人+物"),
        )
        self.assertEqual((count, failed), (3, 0))
        self.assertTrue(os.path.isdir(os.path.join(self.backend.get_user_path("张三"), USER_TODO, "一期", "人+物", pack)))
        stats = {row["user"]: row for row in self.backend.get_done_stats()}
        self.assertEqual(stats["张三"]["distributed_today"], 3)

    def test_harvest_preserves_two_level_category(self):
        src = os.path.join(self.backend.get_user_path("张三"), USER_DONE, "一期", "人+物", "12345678")
        os.makedirs(src)
        result = self.backend.harvest(target_user="张三", collect_unfinished=False)
        self.assertEqual(result[0], 1)
        today = datetime.datetime.now().strftime(DATE_FMT)
        dst = os.path.join(self.backend.dirs["QC"], QC_NEW, today, "一期", "人+物", "张三", "12345678")
        self.assertTrue(os.path.isdir(dst))

    def test_root_level_legacy_done_remains_supported(self):
        src = os.path.join(self.backend.get_user_path("张三"), USER_DONE, "87654321")
        os.makedirs(src)
        result = self.backend.harvest(target_user="张三", collect_unfinished=False)
        self.assertEqual(result[0], 1)
        today = datetime.datetime.now().strftime(DATE_FMT)
        dst = os.path.join(self.backend.dirs["QC"], QC_NEW, today, "张三", "87654321")
        self.assertTrue(os.path.isdir(dst))

    def test_named_image_pack_can_be_harvested_from_category(self):
        src = os.path.join(self.backend.get_user_path("张三"), USER_DONE, "一期", "人+物", "未分组图片_1")
        os.makedirs(src)
        result = self.backend.harvest(target_user="张三", collect_unfinished=False)
        self.assertEqual(result[0], 1)
        today = datetime.datetime.now().strftime(DATE_FMT)
        dst = os.path.join(self.backend.dirs["QC"], QC_NEW, today, "一期", "人+物", "张三", "未分组图片_1")
        self.assertTrue(os.path.isdir(dst))

    def test_history_stats_find_users_below_category_levels(self):
        src = os.path.join(self.backend.get_user_path("张三"), USER_DONE, "一期", "人+物", "12345678")
        os.makedirs(src)
        self.backend.harvest(target_user="张三", collect_unfinished=False)
        today = datetime.datetime.now().strftime(DATE_FMT)
        stats = self.backend.get_history_stats(today)
        self.assertEqual(stats["total_new"], 1)
        self.assertEqual(stats["user_breakdown"][0]["user"], "张三")

    def test_numeric_legacy_task_wins_over_same_named_category(self):
        task = os.path.join(self.backend.get_user_path("张三"), USER_DONE, "23456789")
        os.makedirs(task)
        self.backend.add_recovery_category("23456789")
        tasks = list(self.backend._iter_classified_tasks(os.path.join(self.backend.get_user_path("张三"), USER_DONE)))
        self.assertIn(((), "23456789", task), tasks)

    def test_non_numeric_legacy_task_blocks_same_named_category(self):
        task = os.path.join(self.backend.get_user_path("张三"), USER_DONE, "一期旧任务")
        os.makedirs(task)
        with open(os.path.join(task, "结果.txt"), "w", encoding="utf-8") as f:
            f.write("保留")
        ok, _ = self.backend.add_recovery_category("一期旧任务")
        self.assertFalse(ok)
        tasks = list(self.backend._iter_classified_tasks(os.path.join(self.backend.get_user_path("张三"), USER_DONE)))
        self.assertIn(((), "一期旧任务", task), tasks)

    def test_internal_qa_distribution_supports_classified_results(self):
        self.backend.create_user_folders("验收员")
        date_str = "2026-07-22"
        src = os.path.join(
            self.backend.dirs["QC"], QC_NEW, date_str,
            "一期", "人+物", "张三", "12345678"
        )
        os.makedirs(src, exist_ok=True)
        with open(os.path.join(src, "result.txt"), "w", encoding="utf-8") as f:
            f.write("ok")

        count, message = self.backend.distribute_to_internal_qa(
            date_str, "张三", "验收员", mode="new"
        )

        self.assertEqual((count, message), (1, "成功"))
        qa_root = os.path.join(self.backend.dirs["DIST"], "验收员")
        matches = []
        for current, dirs, files in os.walk(qa_root):
            if os.path.basename(current) == "12345678":
                matches.append(current)
        self.assertEqual(len(matches), 1)
        self.assertIn(os.path.join("一期", "人+物", "12345678"), matches[0])
        self.assertTrue(os.path.isfile(os.path.join(matches[0], "result.txt")))


if __name__ == "__main__":
    unittest.main()
