from pathlib import Path

import pytest

from alchemy.user_tasks import safe_relative_child


def test_safe_relative_child_accepts_nested_task(tmp_path: Path):
    base = tmp_path / "To_Do"
    task = base / "一级" / "00000001"
    task.mkdir(parents=True)
    assert safe_relative_child(base, task) == Path("一级") / "00000001"


def test_safe_relative_child_rejects_folder_outside_todo(tmp_path: Path):
    base = tmp_path / "To_Do"
    base.mkdir()
    outside = tmp_path / "other"
    outside.mkdir()
    with pytest.raises(ValueError):
        safe_relative_child(base, outside)
