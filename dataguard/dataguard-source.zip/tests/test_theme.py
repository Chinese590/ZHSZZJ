import unittest
from pathlib import Path

from alchemy import constants


class EnterpriseThemeTests(unittest.TestCase):
    def test_uses_light_enterprise_theme(self):
        self.assertEqual(constants.UI_THEME, "flatly")
        self.assertEqual(constants.UI_BG, "#F4F7FB")
        self.assertEqual(constants.UI_SURFACE, "#FFFFFF")
        self.assertEqual(constants.UI_PRIMARY, "#1769AA")
        self.assertEqual(constants.UI_TEXT, "#1F2937")
        self.assertEqual(constants.UI_LIST_SELECTION, "#DCEBFA")

    def test_registers_palette_before_building_widgets(self):
        app_source = (Path(__file__).parents[1] / "alchemy" / "app.py").read_text(encoding="utf-8")
        self.assertIn("ThemeDefinition", app_source)
        self.assertIn("register_theme", app_source)
        self.assertIn("theme_use", app_source)
        self.assertIn('active="#EAF2FB"', app_source)
        self.assertNotIn("colors.set", app_source)


if __name__ == "__main__":
    unittest.main()
