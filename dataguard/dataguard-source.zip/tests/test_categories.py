import os
import tempfile
import unittest

from alchemy.backend import AlchemyBackend
from alchemy.constants import USER_DONE, USER_REWORK, USER_TODO


class CategoryTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.backend = AlchemyBackend()
        self.backend.set_root(self.temp.name)
        self.backend.init_directories()
        self.backend.create_user_folders("张三")

    def tearDown(self):
        self.backend.close()
        self.temp.cleanup()

    def test_add_two_level_category_syncs_all_submission_roots(self):
        ok, _ = self.backend.add_recovery_category("一期", "人+物")
        self.assertTrue(ok)
        self.assertEqual(self.backend.get_recovery_categories(), {"一期": ["人+物"]})
        for root in (USER_TODO, USER_DONE, USER_REWORK):
            self.assertTrue(os.path.isdir(os.path.join(self.backend.get_user_path("张三"), root, "一期", "人+物")))

    def test_invalid_category_name_is_rejected(self):
        ok, _ = self.backend.add_recovery_category("一期/非法")
        self.assertFalse(ok)
        self.assertEqual(self.backend.get_recovery_categories(), {})

    def test_new_user_receives_existing_category_tree(self):
        self.backend.add_recovery_category("一期", "人+景")
        ok, _ = self.backend.create_user_folders("李四")
        self.assertTrue(ok)
        self.assertTrue(os.path.isdir(os.path.join(self.backend.get_user_path("李四"), USER_TODO, "一期", "人+景")))

    def test_rename_second_level_updates_all_submission_roots(self):
        self.backend.add_recovery_category("一期", "人+景")
        ok, _ = self.backend.rename_recovery_category("一期", "人+景", "一期", "人+物+景")
        self.assertTrue(ok)
        for root in (USER_TODO, USER_DONE, USER_REWORK):
            base = os.path.join(self.backend.get_user_path("张三"), root, "一期")
            self.assertFalse(os.path.exists(os.path.join(base, "人+景")))
            self.assertTrue(os.path.isdir(os.path.join(base, "人+物+景")))

    def test_nonempty_category_cannot_be_deleted(self):
        self.backend.add_recovery_category("一期", "人+物")
        os.makedirs(os.path.join(self.backend.get_user_path("张三"), USER_TODO, "一期", "人+物", "12345678"))
        ok, _ = self.backend.delete_recovery_category("一期", "人+物")
        self.assertFalse(ok)


if __name__ == "__main__":
    unittest.main()
