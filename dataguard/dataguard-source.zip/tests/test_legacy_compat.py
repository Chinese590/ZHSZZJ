import datetime
import os
import tempfile
import unittest

from alchemy.backend import AlchemyBackend
from alchemy.constants import DATE_FMT, QC_NEW, USER_DONE, USER_TODO


class LegacyCompatibilityTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.backend = AlchemyBackend()
        self.backend.set_root(self.temp.name)
        self.backend.init_directories()
        self.backend.create_user_folders("张三")
        os.makedirs(os.path.join(self.backend.dirs["RAW"], "人体", "20260722"), exist_ok=True)

    def tearDown(self):
        self.backend.close()
        self.temp.cleanup()

    def test_unclassified_folder_distribution_keeps_legacy_path(self):
        src = os.path.join(self.backend.dirs["RAW"], "人体", "20260722", "12345678")
        os.makedirs(src)
        count, failed, _ = self.backend.distribute_specific("张三", "人体", "20260722", ["12345678"])
        self.assertEqual((count, failed), (1, 0))
        self.assertTrue(os.path.isdir(os.path.join(self.backend.get_user_path("张三"), USER_TODO, "12345678")))

    def test_unclassified_done_keeps_legacy_qc_path(self):
        os.makedirs(os.path.join(self.backend.get_user_path("张三"), USER_DONE, "12345678"))
        result = self.backend.harvest(target_user="张三", collect_unfinished=False)
        self.assertEqual(result[0], 1)
        today = datetime.datetime.now().strftime(DATE_FMT)
        self.assertTrue(os.path.isdir(os.path.join(self.backend.dirs["QC"], QC_NEW, today, "张三", "12345678")))

    def test_existing_distribution_target_is_not_overwritten(self):
        src = os.path.join(self.backend.dirs["RAW"], "人体", "20260722", "12345678")
        dst = os.path.join(self.backend.get_user_path("张三"), USER_TODO, "12345678")
        os.makedirs(src)
        os.makedirs(dst)
        with open(os.path.join(dst, "保留.txt"), "w", encoding="utf-8") as f:
            f.write("旧数据")
        count, failed, _ = self.backend.distribute_specific("张三", "人体", "20260722", ["12345678"])
        self.assertEqual((count, failed), (0, 1))
        self.assertTrue(os.path.isfile(os.path.join(dst, "保留.txt")))
        self.assertTrue(os.path.isdir(src))


if __name__ == "__main__":
    unittest.main()
