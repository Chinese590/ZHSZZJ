import os
import sys
import tempfile
import unittest
from unittest import mock


class RuntimePathTests(unittest.TestCase):
    def test_source_mode_uses_project_root(self):
        from alchemy.runtime import application_dir

        expected = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        self.assertEqual(application_dir(), expected)

    def test_frozen_mode_uses_executable_directory(self):
        from alchemy.runtime import application_dir, writable_path

        with tempfile.TemporaryDirectory() as temp:
            fake_exe = os.path.join(temp, "DataGuard.exe")
            with mock.patch.object(sys, "frozen", True, create=True), mock.patch.object(sys, "executable", fake_exe):
                self.assertEqual(application_dir(), temp)
                self.assertEqual(writable_path("alchemy_config.json"), os.path.join(temp, "alchemy_config.json"))


if __name__ == "__main__":
    unittest.main()
