import logging
import os
import tempfile
import unittest

from alchemy.logger import setup_logger


class LoggerRebindingTests(unittest.TestCase):
    @staticmethod
    def _close_alchemy_logger():
        logger = logging.getLogger("alchemy")
        for handler in list(logger.handlers):
            handler.flush()
            handler.close()
            logger.removeHandler(handler)

    def tearDown(self):
        self._close_alchemy_logger()

    def test_rebinds_app_log_when_project_changes(self):
        # Close the active Windows file handle before TemporaryDirectory cleanup.
        # Windows cannot delete app.log while TimedRotatingFileHandler is open.
        with tempfile.TemporaryDirectory() as first, tempfile.TemporaryDirectory() as second:
            try:
                logger = setup_logger(first)
                self.assertEqual(
                    os.path.abspath(logger.handlers[0].baseFilename),
                    os.path.join(first, "app.log"),
                )

                logger = setup_logger(second)

                self.assertEqual(len(logger.handlers), 1)
                self.assertEqual(
                    os.path.abspath(logger.handlers[0].baseFilename),
                    os.path.join(second, "app.log"),
                )
            finally:
                self._close_alchemy_logger()


if __name__ == "__main__":
    unittest.main()
