import datetime
import os
import tempfile
import unittest

from alchemy.backend import AlchemyBackend
from alchemy.constants import DATE_FMT


class PsdBackupTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.backend = AlchemyBackend()
        self.backend.set_root(self.temp.name)
        self.backend.init_directories()

    def tearDown(self):
        self.backend.close()
        self.temp.cleanup()

    def test_recursively_preserves_relative_paths_for_duplicate_psd_names(self):
        task = os.path.join(self.temp.name, "task")
        for subdir in ("A", "B"):
            folder = os.path.join(task, subdir)
            os.makedirs(folder, exist_ok=True)
            with open(os.path.join(folder, "result.psd"), "wb") as f:
                f.write(subdir.encode("ascii"))

        count = self.backend._separate_psd_files(task, "张三", "12345678")

        self.assertEqual(count, 2)
        today = datetime.datetime.now().strftime(DATE_FMT)
        base = os.path.join(self.backend.dirs["PSD_BACKUP"], today, "张三", "12345678")
        self.assertTrue(os.path.isfile(os.path.join(base, "A", "result.psd")))
        self.assertTrue(os.path.isfile(os.path.join(base, "B", "result.psd")))
        self.assertFalse(os.path.exists(os.path.join(task, "A", "result.psd")))
        self.assertFalse(os.path.exists(os.path.join(task, "B", "result.psd")))


if __name__ == "__main__":
    unittest.main()
