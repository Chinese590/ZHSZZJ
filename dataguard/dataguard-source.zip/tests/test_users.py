import os
import tempfile
import unittest

from alchemy.backend import AlchemyBackend


class UserNameValidationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.backend = AlchemyBackend()
        self.backend.set_root(self.temp.name)
        self.backend.init_directories()

    def tearDown(self):
        self.backend.close()
        self.temp.cleanup()

    def test_rejects_path_traversal_and_separators(self):
        for name in ("../x", "a/b", r"a\\b"):
            with self.subTest(name=name):
                ok, _ = self.backend.create_user_folders(name)
                self.assertFalse(ok)
        self.assertFalse(os.path.exists(os.path.join(self.temp.name, "x")))

    def test_rejects_windows_reserved_names(self):
        for name in ("CON", "con.txt", "LPT1", "NUL"):
            with self.subTest(name=name):
                ok, _ = self.backend.create_user_folders(name)
                self.assertFalse(ok)

    def test_rejects_trailing_dot_or_space(self):
        for name in ("张三.", "张三 "):
            with self.subTest(name=name):
                ok, _ = self.backend.create_user_folders(name)
                self.assertFalse(ok)

    def test_accepts_normal_chinese_name(self):
        ok, _ = self.backend.create_user_folders("张三")
        self.assertTrue(ok)
        self.assertTrue(os.path.isdir(os.path.join(self.backend.dirs["DIST"], "张三")))


if __name__ == "__main__":
    unittest.main()
