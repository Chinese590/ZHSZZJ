import datetime
import os
import tempfile
import unittest

from alchemy.backend import AlchemyBackend
from alchemy.constants import DATE_FMT, QC_NEW


class WorkbenchHarvestTests(unittest.TestCase):
    def test_user_submission_workbench_is_recovered(self):
        with tempfile.TemporaryDirectory() as root:
            backend = AlchemyBackend()
            backend.set_root(root)
            backend.init_directories()
            backend.create_user_folders("U")
            source = os.path.join(backend.dirs["QC"], "质检工作台", "待质检", "U", "12345678")
            os.makedirs(source)
            result = backend.harvest(target_user="U", collect_unfinished=False)
            today = datetime.datetime.now().strftime(DATE_FMT)
            target = os.path.join(backend.dirs["QC"], QC_NEW, today, "U", "12345678")
            self.assertEqual(result[0], 1)
            self.assertTrue(os.path.isdir(target))
            self.assertFalse(os.path.exists(source))
            backend.close()


if __name__ == "__main__":
    unittest.main()
