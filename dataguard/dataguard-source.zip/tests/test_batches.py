import os
import tempfile
import unittest

from alchemy.backend import AlchemyBackend


class BatchFilteringTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.backend = AlchemyBackend()
        self.backend.set_root(self.temp.name)
        self.backend.init_directories()
        self.category = "人体"

    def tearDown(self):
        self.backend.close()
        self.temp.cleanup()

    def test_filter_keeps_image_only_batch(self):
        batch = os.path.join(self.backend.dirs["RAW"], self.category, "20260723")
        os.makedirs(batch)
        with open(os.path.join(batch, "a.jpg"), "wb") as f:
            f.write(b"x")

        self.assertIn("20260723", self.backend.get_batches_by_category(self.category, filter_empty=True))

    def test_filter_hides_batch_with_only_empty_group(self):
        batch = os.path.join(self.backend.dirs["RAW"], self.category, "20260724", "【空组】")
        os.makedirs(batch)

        self.assertNotIn("20260724", self.backend.get_batches_by_category(self.category, filter_empty=True))

    def test_filter_keeps_batch_with_task_folder(self):
        task = os.path.join(self.backend.dirs["RAW"], self.category, "20260725", "12345678")
        os.makedirs(task)

        self.assertIn("20260725", self.backend.get_batches_by_category(self.category, filter_empty=True))


if __name__ == "__main__":
    unittest.main()
